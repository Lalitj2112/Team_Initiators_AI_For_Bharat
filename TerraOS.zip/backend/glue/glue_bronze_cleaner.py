import sys, json, boto3

def get_arg(name):
    key = f'--{name}'
    if key in sys.argv:
        return sys.argv[sys.argv.index(key) + 1]
    return None

SOURCE_BUCKET = get_arg('SOURCE_BUCKET')
SOURCE_KEY    = get_arg('SOURCE_KEY')

print(f'[Glue1] SOURCE_BUCKET={SOURCE_BUCKET}')
print(f'[Glue1] SOURCE_KEY={SOURCE_KEY}')

s3   = boto3.client('s3', region_name='ap-south-1')
obj  = s3.get_object(Bucket=SOURCE_BUCKET, Key=SOURCE_KEY)
data = json.loads(obj['Body'].read())

# ── Valid ranges for numeric fields ─────────────────────────────────────────
NPK_RANGES = {
    'nitrogen':        (0, 600),
    'phosphorus':      (0, 200),
    'potassium':       (0, 600),
    'ph':              (0, 14),
    'farm_size_acres': (0, 10000),
}

issues = []

def clean_value(key, value):
    if value is None or str(value).strip().upper() in ('NA', 'N/A', 'NULL', 'NONE', ''):
        issues.append(f'{key} was null/NA — kept as None')
        print(f'[CLEAN] {key}={value!r} → null/NA flagged, proceeding without value')
        return None
    if key in NPK_RANGES:
        try:
            value = float(value)
            min_val, max_val = NPK_RANGES[key]
            if not (min_val <= value <= max_val):
                issues.append(f'{key}={value} out of range [{min_val},{max_val}] — kept as None')
                print(f'[CLEAN] {key}={value} out of range → flagged, proceeding without value')
                return None
        except (TypeError, ValueError):
            issues.append(f'{key}={value!r} not numeric — kept as None')
            print(f'[CLEAN] {key}={value!r} not numeric → flagged, proceeding without value')
            return None
    return value

# ── Apply cleaning ───────────────────────────────────────────────────────────
cleaned = {}
for key, value in data.items():
    cleaned[key] = clean_value(key, value)

# ── Preserve critical ID fields exactly as-is ────────────────────────────────
for id_field in ('farmer_id', 'email', 'farmer_name', 'report_id', 'timestamp', 'submitted_at'):
    if id_field in data:
        cleaned[id_field] = data[id_field]

cleaned['_cleaned']    = True
cleaned['_clean_note'] = 'Processed by Glue Job 1 - Bronze Cleaner'
cleaned['_issues']     = issues
cleaned['_has_issues'] = len(issues) > 0

# ── Save cleaned file — farmerId_timestamp_cleaned.json ─────────────────────
filename  = SOURCE_KEY.split('/')[-1]
clean_key = SOURCE_KEY.replace(
    'inputs/', 'cleaned/'
).replace(filename, filename.replace('.json', '_cleaned.json'))

print(f'[Glue1] Saving to: s3://{SOURCE_BUCKET}/{clean_key}')

s3.put_object(
    Bucket=SOURCE_BUCKET,
    Key=clean_key,
    Body=json.dumps(cleaned, indent=2),
    ContentType='application/json'
)

print(f'[Glue1] Saved: s3://{SOURCE_BUCKET}/{clean_key}')
print(f'[Glue1] Issues found: {len(issues)}')
for issue in issues:
    print(f'  ⚠ {issue}')