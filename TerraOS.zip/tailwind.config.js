/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'soil-dark': '#1C1209',
                'soil-brown': '#3D2B1F',
                'earth': '#6B4226',
                'clay': '#A0522D',
                'bark': '#8B6914',
                'moss': '#2D5016',
                'leaf': '#3E7B27',
                'sprout': '#5A9E3A',
                'lime-green': '#8BC34A',
                'mist': '#F0F4EB',
                'cream': '#FBF8F3',
                'gold': '#D4A017',
                'amber-soil': '#F59E0B',
                'carbon': '#1A2E1A',
            },
            fontFamily: {
                'playfair': ['"Playfair Display"', 'serif'],
                'dm-sans': ['"DM Sans"', 'sans-serif'],
                'dm-mono': ['"DM Mono"', 'monospace'],
            },
            boxShadow: {
                'soil': '0 4px 24px rgba(28,18,9,0.08)',
                'soil-lg': '0 16px 48px rgba(28,18,9,0.14)',
            },
        },
    },
    plugins: [],
}
