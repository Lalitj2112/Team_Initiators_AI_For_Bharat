import { fetchAuthSession } from 'aws-amplify/auth';
import { get, post } from 'aws-amplify/api';

/**
 * Always returns a fresh Authorization header by force-refreshing the Cognito session.
 * This prevents 403 errors caused by stale cached tokens in long-lived browser tabs.
 */
const getAuthHeader = async ({ forceRefresh = true } = {}) => {
    const session = await fetchAuthSession({ forceRefresh });
    const token = session.tokens?.idToken?.toString();
    if (!token) throw new Error('No auth token — please sign in again.');
    return { Authorization: `Bearer ${token}` };
};

/**
 * Wraps an API call with automatic token-refresh retry on 401/403.
 * Usage: withAuth(() => get({ ... }).response)
 */
async function withAuth(fn) {
    try {
        return await fn(await getAuthHeader());
    } catch (err) {
        const status = err?.response?.statusCode ?? err?.response?.status ?? err?.statusCode ?? 0;
        if (status === 401 || status === 403) {
            console.warn('[API] Token may have expired — force-refreshing and retrying…');
            // Force a fresh token and retry once
            return await fn(await getAuthHeader({ forceRefresh: true }));
        }
        throw err;
    }
}

/**
 * Submit soil data for analysis
 * @param {Object} soilData - Soil parameters
 * @returns {Promise<{farmer_id, execution_id, message}>}
 */
export const analyzeSoil = async (soilData) => {
    const headers = await getAuthHeader();
    const response = await post({
        apiName: 'TerraOSAPI',
        path: '/analyze',
        options: { headers, body: soilData },
    }).response;
    return response.body.json();
};

/**
 * Normalize any report shape into a consistent object that all pages can rely on.
 *
 * The history API may return lightweight summary rows:
 *   { report_id, soil_score, grade, crop_type, timestamp, full_report? }
 *
 * OR full report objects straight from S3:
 *   { report_id, farmer_id, timestamp, farmer_data, npk_analysis, suggestions, summary, ... }
 *
 * After normalization every item is guaranteed to have:
 *   soil_score | grade | crop_type | location | timestamp | full_report (the complete nested obj)
 */
function normalizeReport(raw) {
    if (!raw) return raw;

    // ── 1. If full_report is a JSON string (common DynamoDB pattern), parse it ──
    let base = { ...raw };
    if (base.full_report && typeof base.full_report === 'string') {
        try {
            base.full_report = JSON.parse(base.full_report);
            console.info('[normalize] parsed full_report JSON string');
        } catch (_) { /* leave as-is */ }
    }

    // ── 2. Determine which object holds the nested report fields ──
    const full = (base.farmer_data || base.npk_analysis || base.suggestions)
        ? base
        : (base.full_report || base);

    const fd = full.farmer_data || {};
    const sug = full.suggestions || {};
    const sum = full.summary || {};

    console.info('[normalize] raw keys:', Object.keys(base));
    console.info('[normalize] sum:', sum, '| sug score:', sug.overall_soil_score);

    // ── 3. Extract with fallback chain ──
    const soil_score = (base.soil_score > 0 ? base.soil_score : null)
        ?? (sum.soil_score > 0 ? sum.soil_score : null)
        ?? (sug.overall_soil_score > 0 ? sug.overall_soil_score : null)
        ?? 0;

    const grade = (base.grade && base.grade !== '\u2014' && base.grade !== '-' ? base.grade : null)
        ?? (sum.grade && sum.grade !== '\u2014' ? sum.grade : null)
        ?? sug.soil_health_grade
        ?? '\u2014';

    const crop_type = (base.crop_type && base.crop_type !== 'Unknown' ? base.crop_type : null)
        || fd.crop_type
        || fd.crop_planned
        || full.crop_type
        || '';

    const location = base.location || fd.location || '';
    const timestamp = base.timestamp || full.timestamp || full.generated_at || '';

    const normalized = { ...base, soil_score, grade, crop_type, location, timestamp, full_report: full };
    console.info('[normalize] \u2192 soil_score:', soil_score, '| grade:', grade, '| ts:', timestamp);
    return normalized;
}

/**
 * Fetch a soil report for a given farmer.
 * @param {string} farmerId - The farmer ID returned from /analyze
 * @returns {Promise<Object>} - Normalized full report data
 */
export const fetchReport = async (farmerId) => {
    const headers = await getAuthHeader();
    try {
        const response = await get({
            apiName: 'TerraOSAPI',
            path: `/report/${farmerId}`,
            options: {
                headers,
                queryParams: { latest: 'true' },   // ← get single full report, not all reports array
            },
        }).response;

        // 202 Accepted = still processing
        if (response.statusCode === 202) return null;

        const data = await response.body.json();
        console.log('[fetchReport] RAW API response:', JSON.stringify(data, null, 2));

        // Lambda returns { status: 'processing', ... } → keep polling
        if (data?.status === 'processing') return null;

        // Lambda returns { status: 'complete', report: {...} } → unwrap
        const raw = data?.report ?? data;
        console.log('[fetchReport] raw top-level keys:', Object.keys(raw || {}));
        console.log('[fetchReport] has farmer_data:', !!raw?.farmer_data);
        console.log('[fetchReport] has npk_analysis:', !!raw?.npk_analysis);

        const normalized = normalizeReport(raw);
        return normalized;
    } catch (e) {
        const status = e?.response?.statusCode ?? e?.response?.status ?? 0;
        if (status === 202 || status === 404 || status === 0) return null;
        throw e;
    }
};

/**
 * Fetch all historical reports for a farmer.
 * GET /history/{farmerId}
 * Returns { reports: [normalizedReport, ...] }
 */
export const fetchAllReports = async (farmerId) => {
    const headers = await getAuthHeader();
    const response = await get({
        apiName: 'TerraOSAPI',
        path: `/history/${farmerId}`,
        options: { headers },
    }).response;

    // Amplify REST API does NOT throw on 4xx — handle manually
    if (response.statusCode >= 400) {
        const errBody = await response.body.json().catch(() => ({}));
        throw new Error(errBody?.error || `HTTP ${response.statusCode}`);
    }

    const data = await response.body.json();
    console.log('[API] /history raw response:', data);

    // Lambda returns { status: 'success', reports: [...], count: n }
    const rawReports = data.reports || [];
    const normalized = rawReports.map(normalizeReport);
    console.log('[API] normalized reports[0]:', normalized[0]);
    return { reports: normalized };
};

// Alias kept for backward compatibility
export const fetchReportHistory = fetchAllReports;
