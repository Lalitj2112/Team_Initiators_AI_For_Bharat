/**
 * translateService.js
 *
 * Single-tier translation: Amazon Translate with chunking + exponential-backoff retries.
 * No third-party APIs — all translation stays within AWS.
 *
 * Chunking strategy:
 *   Long texts are split at sentence boundaries (. ! ? ।) into chunks ≤ 4500 chars
 *   (safe below AWS Translate's 5000-char hard limit). Each chunk is translated
 *   independently and the results rejoined — this gives better translation accuracy
 *   since Amazon Translate gets shorter, complete sentences to work with.
 *
 * Retry strategy (per chunk):
 *   Attempt 1 → wait 500 ms → Attempt 2 → wait 1000 ms → Attempt 3
 *   If all attempts fail → chunk is returned untranslated (graceful fallback).
 *
 * Results are cached in-memory (full text → translated text) to avoid repeated calls.
 */
import { TranslateClient, TranslateTextCommand } from '@aws-sdk/client-translate';
import { fetchAuthSession } from 'aws-amplify/auth';

const REGION = import.meta.env.VITE_AWS_REGION || 'ap-south-1';
const MAX_RETRIES = 3;
const BASE_DELAY_MS = 500;       // 500ms, 1000ms per retry
const CHUNK_MAX_CHARS = 4500;    // safely below AWS's 5000-char limit

// In-memory cache: "targetLang::src_text" → translated string
const cache = new Map();

// ─── AWS client ────────────────────────────────────────────────────────────

async function getClient() {
    // ① Cognito Identity Pool credentials (preferred)
    try {
        const session = await fetchAuthSession();
        const creds = session.credentials;
        if (creds?.accessKeyId) {
            return new TranslateClient({
                region: REGION,
                credentials: {
                    accessKeyId: creds.accessKeyId,
                    secretAccessKey: creds.secretAccessKey,
                    sessionToken: creds.sessionToken,
                },
            });
        }
    } catch (_) { /* fall through */ }

    // ② Static .env credentials
    const accessKeyId = import.meta.env.VITE_AWS_ACCESS_KEY_ID;
    const secretAccessKey = import.meta.env.VITE_AWS_SECRET_ACCESS_KEY;
    if (!accessKeyId || !secretAccessKey) {
        throw new Error(
            'No AWS credentials: add VITE_AWS_ACCESS_KEY_ID and VITE_AWS_SECRET_ACCESS_KEY to .env'
        );
    }
    return new TranslateClient({
        region: REGION,
        credentials: { accessKeyId, secretAccessKey },
    });
}

// ─── Chunking ──────────────────────────────────────────────────────────────

/**
 * Split text into sentence-aware chunks of at most `maxLen` characters.
 * Splits preferentially at sentence boundaries (. ! ? ।) to preserve meaning,
 * then falls back to word boundaries for extremely long sentences.
 */
function splitIntoChunks(text, maxLen = CHUNK_MAX_CHARS) {
    if (text.length <= maxLen) return [text];

    const chunks = [];
    // Split on sentence-ending punctuation followed by whitespace
    const sentences = text.split(/(?<=[.!?।])\s+/);
    let current = '';

    for (const sentence of sentences) {
        const candidate = current ? `${current} ${sentence}` : sentence;

        if (candidate.length <= maxLen) {
            current = candidate;
        } else {
            // Flush current chunk
            if (current) chunks.push(current.trim());

            // If a single sentence exceeds the limit, hard-split by words
            if (sentence.length > maxLen) {
                const words = sentence.split(' ');
                let part = '';
                for (const word of words) {
                    const next = part ? `${part} ${word}` : word;
                    if (next.length > maxLen) {
                        if (part) chunks.push(part.trim());
                        part = word;
                    } else {
                        part = next;
                    }
                }
                current = part;
            } else {
                current = sentence;
            }
        }
    }

    if (current) chunks.push(current.trim());
    return chunks;
}

// ─── Retry helpers ─────────────────────────────────────────────────────────

/** True for transient AWS errors that are safe to retry */
function isRetryable(err) {
    const retryableCodes = [
        'ThrottlingException',
        'TooManyRequestsException',
        'ServiceUnavailableException',
        'InternalServerError',
        'RequestExpired',
        'RequestTimeout',
    ];
    return (
        retryableCodes.includes(err?.name) ||
        retryableCodes.includes(err?.code) ||
        err?.message?.toLowerCase().includes('throttl') ||
        err?.message?.toLowerCase().includes('too many requests') ||
        (err?.$metadata?.httpStatusCode >= 500)
    );
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ─── Single-chunk translation with retry ───────────────────────────────────

async function translateChunk(text, targetLang) {
    let lastErr;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const client = await getClient();
            const res = await client.send(
                new TranslateTextCommand({
                    Text: text,
                    SourceLanguageCode: 'en',
                    TargetLanguageCode: targetLang,
                })
            );
            const translated = res.TranslatedText;
            if (translated) {
                console.info(
                    `[Translate] ✅ chunk OK (attempt ${attempt}):`,
                    text.slice(0, 40)
                );
                return translated;
            }
            throw new Error('Empty TranslatedText returned');
        } catch (err) {
            lastErr = err;
            const shouldRetry = isRetryable(err) && attempt < MAX_RETRIES;
            console.warn(
                `[Translate] ⚠️ attempt ${attempt}/${MAX_RETRIES} — ${err.name || err.message}`,
                shouldRetry ? `retrying in ${BASE_DELAY_MS * attempt}ms…` : 'giving up.'
            );
            if (shouldRetry) await sleep(BASE_DELAY_MS * attempt);
        }
    }

    // All retries exhausted — return the original chunk untranslated
    console.error('[Translate] ❌ chunk failed after all retries:', lastErr?.message);
    return text;
}

// ─── Public API ────────────────────────────────────────────────────────────

/**
 * Translate a string via Amazon Translate.
 * Long texts are split into sentence-aware chunks and reassembled after translation.
 * Results are cached. Falls back to the original text if all retries fail.
 */
export async function translateText(text, targetLang = 'hi') {
    if (!text?.trim() || targetLang === 'en') return text;

    const cacheKey = `${targetLang}::${text}`;
    if (cache.has(cacheKey)) return cache.get(cacheKey);

    const chunks = splitIntoChunks(text);
    console.info(`[Translate] translating ${chunks.length} chunk(s) → ${targetLang}`);

    // Translate chunks sequentially to stay within AWS rate limits
    const translated = [];
    for (const chunk of chunks) {
        translated.push(await translateChunk(chunk, targetLang));
    }

    const result = translated.join(' ');
    cache.set(cacheKey, result);
    return result;
}

/**
 * Translate an object { key: string } — each value goes through the chunked translator.
 * Keys with empty / non-string values are skipped.
 */
export async function translateBatch(stringsObj, targetLang = 'hi') {
    if (targetLang === 'en') return stringsObj;
    const entries = Object.entries(stringsObj).filter(
        ([, v]) => typeof v === 'string' && v.trim()
    );
    const results = await Promise.all(
        entries.map(async ([k, v]) => [k, await translateText(v, targetLang)])
    );
    return Object.fromEntries(results);
}

/** Clear the in-memory cache (call on sign-out) */
export function clearTranslationCache() {
    cache.clear();
}
