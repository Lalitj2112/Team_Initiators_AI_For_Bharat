import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { fetchAuthSession, getCurrentUser, signOut as amplifySignOut } from 'aws-amplify/auth';

const AuthContext = createContext(null);

export const useAuth = () => {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error('useAuth must be used within AuthProvider');
    return ctx;
};

export const AuthProvider = ({ children }) => {
    const [currentUser, setCurrentUser] = useState(null); // { name, email, sub }
    const [farmerId, setFarmerId] = useState(() =>
        localStorage.getItem('terraos_farmer_id') ||
        localStorage.getItem('farmer_id') || null
    );

    const [lastReport, setLastReport] = useState(() => {
        try { return JSON.parse(localStorage.getItem('terraos_last_report')) || null; } catch { return null; }
    });
    const [loading, setLoading] = useState(true);

    const checkAuth = useCallback(async () => {
        try {
            const user = await getCurrentUser();
            // forceRefresh: true ensures we always get a valid, non-expired token
            // even if the browser tab has been open for a long time.
            const session = await fetchAuthSession({ forceRefresh: true });
            const payload = session.tokens?.idToken?.payload || {};
            const sub = user.userId;

            setCurrentUser({
                sub,
                email: payload.email || user.username,
                name: payload.name || payload.email || user.username,
            });

            // Clear stale farmer_id from localStorage if it belongs to a different user.
            // A mismatched ID causes 403s because the API enforces user isolation.
            const storedId = localStorage.getItem('terraos_farmer_id') || localStorage.getItem('farmer_id');
            if (storedId && storedId !== sub) {
                console.warn('[Auth] Stale farmer_id detected — clearing:', storedId, '→', sub);
                localStorage.removeItem('terraos_farmer_id');
                localStorage.removeItem('farmer_id');
                // Also clear any cached report — it belongs to the previous user
                localStorage.removeItem('terraos_last_report');
                setLastReport(null);
            }
        } catch {
            setCurrentUser(null);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { checkAuth(); }, [checkAuth]);

    const signOut = async () => {
        await amplifySignOut();
        setCurrentUser(null);
        setFarmerId(null);
        setLastReport(null);
        localStorage.removeItem('terraos_farmer_id');
        localStorage.removeItem('farmer_id');
        localStorage.removeItem('terraos_last_report');
    };

    const updateFarmerId = (id) => {
        setFarmerId(id);
        if (id) {
            localStorage.setItem('terraos_farmer_id', id);
            localStorage.setItem('farmer_id', id); // also write the key the backend sample uses
        } else {
            localStorage.removeItem('terraos_farmer_id');
            localStorage.removeItem('farmer_id');
        }
    };

    const updateLastReport = (report) => {
        setLastReport(report);
        if (report) localStorage.setItem('terraos_last_report', JSON.stringify(report));
        else localStorage.removeItem('terraos_last_report');
    };

    return (
        <AuthContext.Provider value={{
            currentUser,
            farmerId,
            lastReport,
            loading,
            checkAuth,
            signOut,
            updateFarmerId,
            updateLastReport,
        }}>
            {children}
        </AuthContext.Provider>
    );
};
