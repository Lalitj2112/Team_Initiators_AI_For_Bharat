/**
 * LanguageContext.jsx
 *
 * Provides:
 *   lang        – 'en' | 'hi' | 'mr' | 'te' | 'ta' | 'bn'
 *   setLang     – switch language (persists to localStorage)
 *   t(key)      – get static UI string for current lang
 *   translateDynamic(text) – translate a dynamic string via Amazon Translate (cached)
 */
import { createContext, useContext, useState, useCallback } from 'react';
import en from '../translations/en.js';
import hi from '../translations/hi.js';
import te from '../translations/te.js';
import mr from '../translations/mr.js';
import ta from '../translations/ta.js';
import bn from '../translations/bn.js';
import { translateText } from '../services/translateService.js';

const LanguageContext = createContext(null);

const STRINGS = { en, hi, te, mr, ta, bn };

// Auto-detect browser language → one of our supported codes
function detectBrowserLang() {
    const b = (navigator.language || navigator.userLanguage || 'en').toLowerCase();
    if (b.startsWith('hi')) return 'hi';
    if (b.startsWith('te')) return 'te';
    if (b.startsWith('mr')) return 'mr';
    if (b.startsWith('ta')) return 'ta';
    if (b.startsWith('bn') || b.startsWith('be')) return 'bn';
    return 'en';
}

export function LanguageProvider({ children }) {
    const [lang, setLangState] = useState(() => {
        const stored = localStorage.getItem('terraos_lang');
        if (stored && STRINGS[stored]) return stored;
        return detectBrowserLang();
    });

    const setLang = useCallback((l) => {
        localStorage.setItem('terraos_lang', l);
        setLangState(l);
    }, []);

    /** Get a static UI string by key — falls back to English */
    const t = useCallback((key) => {
        return STRINGS[lang]?.[key] ?? STRINGS['en']?.[key] ?? key;
    }, [lang]);

    /**
     * Translate a dynamic string (API-generated content) via Amazon Translate.
     * Returns a Promise<string>. Falls back to the original text on error.
     */
    const translateDynamic = useCallback((text) => {
        if (lang === 'en' || !text) return Promise.resolve(text);
        return translateText(text, lang);
    }, [lang]);

    return (
        <LanguageContext.Provider value={{ lang, setLang, t, translateDynamic }}>
            {children}
        </LanguageContext.Provider>
    );
}

export function useLanguage() {
    const ctx = useContext(LanguageContext);
    if (!ctx) throw new Error('useLanguage must be used inside LanguageProvider');
    return ctx;
}
