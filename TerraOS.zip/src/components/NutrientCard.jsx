/**
 * NPK status card matching HTML reference
 * @param {string} letter - 'N', 'P', or 'K'
 * @param {string|number} value - e.g. "145 kg/ha"
 * @param {'ok'|'low'|'high'|'critical'} status
 * @param {string} recommendation
 */
export default function NutrientCard({ letter, value, status = 'ok', recommendation }) {
    const statusConfig = {
        ok: { bg: '#e8f5e9', letterColor: '#2e7d32', valueColor: '#388e3c', tagColor: '#66bb6a', tag: 'Adequate ✓' },
        low: { bg: '#fff8e1', letterColor: '#f57f17', valueColor: '#f9a825', tagColor: '#ffa726', tag: 'Low ↑' },
        high: { bg: '#fce4ec', letterColor: '#c62828', valueColor: '#e53935', tagColor: '#ef9a9a', tag: 'High ↓' },
        critical: { bg: '#fce4ec', letterColor: '#b71c1c', valueColor: '#c62828', tagColor: '#ef5350', tag: 'Critical!' },
    };
    const cfg = statusConfig[status] || statusConfig.ok;

    return (
        <div style={{
            padding: 10,
            borderRadius: 10,
            background: cfg.bg,
            textAlign: 'center',
        }}>
            <div style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: '1.3rem', fontWeight: 900,
                marginBottom: 2,
                color: cfg.letterColor,
            }}>
                {letter}
            </div>
            <div style={{
                fontFamily: "'DM Mono', monospace",
                fontSize: '0.85rem', fontWeight: 500,
                color: cfg.valueColor,
            }}>
                {value}
            </div>
            <div style={{
                fontSize: '0.65rem', fontWeight: 600,
                textTransform: 'uppercase', marginTop: 2,
                color: cfg.tagColor,
            }}>
                {cfg.tag}
            </div>
            {recommendation && (
                <div style={{
                    fontSize: '0.72rem',
                    color: 'var(--text-secondary)',
                    marginTop: 6,
                    lineHeight: 1.4,
                    textAlign: 'left',
                }}>
                    {recommendation}
                </div>
            )}
        </div>
    );
}
