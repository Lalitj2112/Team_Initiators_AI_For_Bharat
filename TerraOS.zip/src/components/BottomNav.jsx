import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext.jsx';

const NAV_ITEMS = [
    { path: '/home', icon: '🏠', key: 'nav.home' },
    { path: '/analyze', icon: '🧪', key: 'nav.analyze' },
    { path: '/history', icon: '📋', key: 'nav.reports' },
    { path: '/profile', icon: '👤', key: 'nav.profile' },
];

const LANGS = [
    { code: 'en', label: 'EN', native: 'English' },
    { code: 'hi', label: 'हि', native: 'हिन्दी' },
    { code: 'mr', label: 'म', native: 'मराठी' },
    { code: 'te', label: 'తె', native: 'తెలుగు' },
    { code: 'ta', label: 'த', native: 'தமிழ்' },
    { code: 'bn', label: 'বা', native: 'বাংলা' },
];

export default function BottomNav() {
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const { lang, setLang, t } = useLanguage();
    const [open, setOpen] = useState(false);
    const dropRef = useRef(null);

    const current = LANGS.find(l => l.code === lang) || LANGS[0];

    // Close dropdown when clicking outside
    useEffect(() => {
        if (!open) return;
        const handler = (e) => {
            if (dropRef.current && !dropRef.current.contains(e.target)) {
                setOpen(false);
            }
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, [open]);

    return (
        <>
            {/* Language dropdown — rendered above the nav at portal level */}
            {open && (
                <div
                    onClick={() => setOpen(false)}
                    style={{
                        position: 'fixed', inset: 0,
                        zIndex: 199,
                        background: 'transparent',
                    }}
                />
            )}

            <nav className="bottom-nav-root" style={{
                position: 'fixed',
                bottom: 0, left: 0, right: 0,
                background: 'white',
                borderTop: '1px solid var(--border)',
                display: 'flex',
                justifyContent: 'space-around',
                alignItems: 'center',
                padding: '6px 0 10px',
                zIndex: 200,
            }}>
                <style>{`
                    @media (min-width: 768px) {
                        .bottom-nav-root { display: none !important; }
                    }
                    .lang-option:hover {
                        background: #f0faf0 !important;
                    }
                `}</style>

                {NAV_ITEMS.map(({ path, icon, key }) => {
                    const active = pathname === path || (path === '/home' && pathname === '/');
                    return (
                        <button
                            key={path}
                            onClick={() => navigate(path)}
                            style={{
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                gap: 3,
                                cursor: 'pointer',
                                padding: '4px 12px',
                                borderRadius: 8,
                                border: 'none',
                                background: 'none',
                                transition: 'all 0.2s',
                            }}
                        >
                            <div style={{ fontSize: '1.2rem' }}>{icon}</div>
                            <div style={{
                                fontSize: '0.65rem',
                                fontWeight: 600,
                                textTransform: 'uppercase',
                                letterSpacing: '0.06em',
                                color: active ? 'var(--leaf)' : 'var(--text-muted)',
                                fontFamily: "'DM Sans', sans-serif",
                            }}>
                                {t(key)}
                            </div>
                            {active && (
                                <div style={{
                                    width: 4, height: 4,
                                    borderRadius: '50%',
                                    background: 'var(--leaf)',
                                }} />
                            )}
                        </button>
                    );
                })}

                {/* ── Language selector ── */}
                <div ref={dropRef} style={{ position: 'relative' }}>

                    {/* Dropdown panel — opens upward */}
                    {open && (
                        <div style={{
                            position: 'absolute',
                            bottom: 'calc(100% + 10px)',
                            right: 0,
                            background: 'white',
                            borderRadius: 14,
                            boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
                            border: '1px solid var(--border)',
                            overflow: 'hidden',
                            minWidth: 160,
                            zIndex: 300,
                            animation: 'fadeUp 0.18s ease',
                        }}>
                            <style>{`
                                @keyframes fadeUp {
                                    from { opacity: 0; transform: translateY(8px); }
                                    to   { opacity: 1; transform: translateY(0); }
                                }
                            `}</style>

                            <div style={{
                                padding: '8px 12px 6px',
                                fontSize: '0.62rem',
                                fontWeight: 700,
                                textTransform: 'uppercase',
                                letterSpacing: '0.1em',
                                color: 'var(--text-muted)',
                                fontFamily: "'DM Sans', sans-serif",
                                borderBottom: '1px solid var(--border)',
                            }}>
                                Select Language
                            </div>

                            {LANGS.map(l => (
                                <button
                                    key={l.code}
                                    className="lang-option"
                                    onClick={() => { setLang(l.code); setOpen(false); }}
                                    style={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 10,
                                        width: '100%',
                                        padding: '9px 14px',
                                        border: 'none',
                                        background: l.code === lang ? '#f0faf0' : 'white',
                                        cursor: 'pointer',
                                        textAlign: 'left',
                                        transition: 'background 0.15s',
                                    }}
                                >
                                    <span style={{
                                        width: 28, height: 28,
                                        borderRadius: 8,
                                        background: l.code === lang ? 'var(--moss)' : '#f4f4f4',
                                        color: l.code === lang ? 'white' : 'var(--text-primary)',
                                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                                        fontSize: '0.8rem', fontWeight: 700,
                                        flexShrink: 0,
                                        fontFamily: "'DM Sans', sans-serif",
                                    }}>
                                        {l.label}
                                    </span>
                                    <span style={{
                                        fontSize: '0.85rem',
                                        fontWeight: l.code === lang ? 700 : 500,
                                        color: l.code === lang ? 'var(--moss)' : 'var(--text-primary)',
                                        fontFamily: "'DM Sans', sans-serif",
                                    }}>
                                        {l.native}
                                    </span>
                                    {l.code === lang && (
                                        <span style={{
                                            marginLeft: 'auto',
                                            color: 'var(--leaf)',
                                            fontSize: '0.9rem',
                                        }}>✓</span>
                                    )}
                                </button>
                            ))}
                        </div>
                    )}

                    {/* Trigger button */}
                    <button
                        onClick={() => setOpen(o => !o)}
                        style={{
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: 3,
                            cursor: 'pointer',
                            padding: '4px 10px',
                            borderRadius: 8,
                            border: 'none',
                            background: 'none',
                        }}
                    >
                        <div style={{
                            fontSize: '0.75rem',
                            fontWeight: 700,
                            background: open ? 'var(--leaf)' : 'var(--moss)',
                            color: 'white',
                            borderRadius: 10,
                            padding: '2px 8px',
                            fontFamily: "'DM Sans', sans-serif",
                            transition: 'background 0.2s',
                        }}>
                            {current.label}
                        </div>
                        <div style={{
                            fontSize: '0.6rem',
                            color: 'var(--text-muted)',
                            fontFamily: "'DM Sans', sans-serif",
                        }}>
                            {current.native}
                        </div>
                    </button>
                </div>
            </nav>
        </>
    );
}
