import { useState } from 'react';

/**
 * Accordion practice item matching HTML reference
 * @param {string} icon - emoji
 * @param {string} name - practice name
 * @param {string} benefit - benefit description
 * @param {string} howTo - how-to instructions
 * @param {boolean} defaultOpen
 */
export default function PracticeAccordion({ icon, name, benefit, howTo, defaultOpen = false }) {
    const [open, setOpen] = useState(defaultOpen);

    return (
        <div style={{
            border: '1.5px solid var(--border)',
            borderRadius: 12,
            marginBottom: '0.6rem',
            overflow: 'hidden',
            cursor: 'pointer',
        }}>
            <div
                onClick={() => setOpen(o => !o)}
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '12px 14px',
                    background: '#fafaf8',
                }}
            >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ fontSize: '1.1rem' }}>{icon}</div>
                    <div style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--text-primary)' }}>
                        {name}
                    </div>
                </div>
                <div style={{
                    color: 'var(--text-muted)',
                    fontSize: '0.8rem',
                    transition: 'transform 0.2s',
                    transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
                }}>
                    ▼
                </div>
            </div>

            {open && (
                <div style={{
                    padding: '12px 14px',
                    background: 'white',
                    borderTop: '1px solid var(--border)',
                    animation: 'fadeInUp 0.2s ease-out',
                }}>
                    <div style={{
                        fontSize: '0.82rem',
                        color: 'var(--text-secondary)',
                        lineHeight: 1.5,
                        marginBottom: 8,
                    }}>
                        {benefit}
                    </div>
                    <div style={{
                        fontSize: '0.78rem',
                        color: 'var(--text-muted)',
                        lineHeight: 1.5,
                        padding: 8,
                        background: '#f0f8ea',
                        borderRadius: 6,
                    }}>
                        {howTo}
                    </div>
                </div>
            )}
        </div>
    );
}
