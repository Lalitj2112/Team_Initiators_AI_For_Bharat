import { useEffect, useRef } from 'react';

/**
 * Circular SVG score gauge with animated stroke-dashoffset
 * @param {number} score - 0 to 100
 * @param {number} size - SVG size in px (default 90)
 * @param {number} strokeWidth - default 8
 */
export default function SoilScoreGauge({ score = 0, size = 90, strokeWidth = 8 }) {
    const circleRef = useRef(null);
    const radius = (size / 2) - strokeWidth;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (score / 100) * circumference;

    // Score-based color
    const getColor = (s) => {
        if (s >= 80) return '#5A9E3A'; // sprout
        if (s >= 60) return '#3E7B27'; // leaf
        return '#F59E0B';              // amber
    };
    const color = getColor(score);

    // Grade
    const getGrade = (s) => {
        if (s >= 90) return 'A+';
        if (s >= 80) return 'A';
        if (s >= 70) return 'B';
        if (s >= 60) return 'C';
        if (s >= 50) return 'D';
        return 'F';
    };

    const getGradeLabel = (s) => {
        if (s >= 80) return 'Excellent Health';
        if (s >= 70) return 'Good Health';
        if (s >= 60) return 'Fair Health';
        if (s >= 50) return 'Needs Attention';
        return 'Critical';
    };

    useEffect(() => {
        if (circleRef.current) {
            circleRef.current.style.strokeDashoffset = circumference; // start at 0%
            requestAnimationFrame(() => {
                circleRef.current.style.transition = 'stroke-dashoffset 1.2s ease-out';
                circleRef.current.style.strokeDashoffset = offset;
            });
        }
    }, [score, offset, circumference]);

    return (
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', flexWrap: 'wrap' }}>
            {/* Circular Gauge */}
            <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
                <svg
                    width={size}
                    height={size}
                    viewBox={`0 0 ${size} ${size}`}
                    style={{ transform: 'rotate(-90deg)' }}
                >
                    {/* Background track */}
                    <circle
                        cx={size / 2}
                        cy={size / 2}
                        r={radius}
                        fill="none"
                        stroke="#e8f5e9"
                        strokeWidth={strokeWidth}
                    />
                    {/* Score arc */}
                    <circle
                        ref={circleRef}
                        cx={size / 2}
                        cy={size / 2}
                        r={radius}
                        fill="none"
                        stroke={color}
                        strokeWidth={strokeWidth}
                        strokeDasharray={circumference}
                        strokeDashoffset={circumference}
                        strokeLinecap="round"
                    />
                </svg>
                {/* Center text */}
                <div style={{
                    position: 'absolute', inset: 0,
                    display: 'flex', flexDirection: 'column',
                    alignItems: 'center', justifyContent: 'center',
                    fontFamily: "'Playfair Display', serif",
                }}>
                    <div style={{ fontSize: size >= 90 ? '1.6rem' : '1.1rem', fontWeight: 900, color, lineHeight: 1 }}>
                        {score}
                    </div>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>/100</div>
                </div>
            </div>

            {/* Grade + Label */}
            <div>
                <div style={{
                    display: 'inline-flex',
                    alignItems: 'center', justifyContent: 'center',
                    width: 36, height: 36,
                    background: `linear-gradient(135deg, ${color}, #8BC34A)`,
                    color: 'white',
                    borderRadius: 8,
                    fontFamily: "'Playfair Display', serif",
                    fontSize: '1.1rem', fontWeight: 900,
                    marginBottom: '0.4rem',
                }}>
                    {getGrade(score)}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    {getGradeLabel(score)}
                </div>
            </div>
        </div>
    );
}
