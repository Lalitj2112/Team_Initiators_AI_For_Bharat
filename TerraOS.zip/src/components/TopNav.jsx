import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';

const NAV_KEYS = [
    { path: '/home', key: 'nav.home' },
    { path: '/analyze', key: 'nav.analyze' },
    { path: '/history', key: 'nav.reports' },
    { path: '/profile', key: 'nav.profile' },
];

export default function TopNav() {
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const { currentUser } = useAuth();
    const { lang, setLang, t } = useLanguage();

    const initials = currentUser?.name
        ? currentUser.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
        : 'TF';

    return (
        <nav style={{
            position: 'fixed',
            top: 0, left: 0, right: 0,
            zIndex: 1000,
            background: 'rgba(251,248,243,0.92)',
            backdropFilter: 'blur(16px)',
            borderBottom: '1px solid var(--border)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 2rem',
            height: 64,
        }}>
            {/* Logo */}
            <a
                href="/home"
                onClick={e => { e.preventDefault(); navigate('/home'); }}
                style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    fontFamily: "'Playfair Display', serif",
                    fontSize: '1.4rem', fontWeight: 700,
                    color: 'var(--moss)',
                    textDecoration: 'none',
                }}
            >
                <div className="leaf-shape" style={{ width: 32, height: 32, fontSize: 16 }}>
                    <span>🌿</span>
                </div>
                TerraOS
            </a>

            {/* Nav Links */}
            <div style={{ display: 'flex', gap: 4 }}>
                {NAV_KEYS.map(({ path, key }) => {
                    const active = pathname === path;
                    return (
                        <button
                            key={path}
                            onClick={() => navigate(path)}
                            style={{
                                padding: '6px 14px',
                                border: 'none',
                                cursor: 'pointer',
                                borderRadius: 20,
                                fontFamily: "'DM Sans', sans-serif",
                                fontSize: '0.8rem', fontWeight: 500,
                                background: active ? 'var(--moss)' : 'transparent',
                                color: active ? 'white' : 'var(--text-secondary)',
                                transition: 'all 0.2s',
                            }}
                        >
                            {t(key)}
                        </button>
                    );
                })}
            </div>

            {/* Right: User + Language Toggle */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                {/* Language dropdown */}
                <select
                    value={lang}
                    onChange={e => setLang(e.target.value)}
                    style={{
                        padding: '5px 12px',
                        borderRadius: 20,
                        border: '1.5px solid var(--moss)',
                        background: 'white',
                        color: 'var(--moss)',
                        fontFamily: "'DM Sans', sans-serif",
                        fontSize: '0.78rem',
                        fontWeight: 700,
                        cursor: 'pointer',
                        outline: 'none',
                        boxShadow: '0 1px 6px rgba(45,80,22,0.1)',
                        appearance: 'none',
                        paddingRight: 26,
                        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%232d5016'/%3E%3C/svg%3E")`,
                        backgroundRepeat: 'no-repeat',
                        backgroundPosition: 'right 9px center',
                    }}
                >
                    <option value="en">🌐 English</option>
                    <option value="hi">🇮🇳 हिन्दी</option>
                    <option value="mr">🇮🇳 मराठी</option>
                    <option value="te">🇮🇳 తెలుగు</option>
                    <option value="ta">🇮🇳 தமிழ்</option>
                    <option value="bn">🇮🇳 বাংলা</option>
                </select>

                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    {currentUser?.email || ''}
                </span>
                <div style={{
                    width: 34, height: 34,
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, var(--leaf), var(--sprout))',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'white', fontSize: '0.8rem', fontWeight: 600,
                }}>
                    {initials}
                </div>
            </div>
        </nav>
    );
}
