import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function ProtectedRoute() {
    const { currentUser, loading } = useAuth();

    if (loading) {
        return (
            <div style={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'var(--cream)',
            }}>
                <div style={{ textAlign: 'center' }}>
                    <div style={{
                        width: 56, height: 56,
                        borderRadius: '50%',
                        border: '3px solid var(--mist)',
                        borderTopColor: 'var(--leaf)',
                        animation: 'spin 0.8s linear infinite',
                        margin: '0 auto 1rem',
                    }} />
                    <div style={{
                        fontFamily: "'DM Sans', sans-serif",
                        color: 'var(--text-muted)',
                        fontSize: '0.9rem',
                    }}>Loading TerraOS...</div>
                </div>
                <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            </div>
        );
    }

    return currentUser ? <Outlet /> : <Navigate to="/" replace />;
}
