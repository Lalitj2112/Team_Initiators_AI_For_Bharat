/**
 * CarbonCard — eligibility status + curated India-specific carbon programs.
 * Fully translated for all 5 supported languages.
 */
import { useLanguage } from '../context/LanguageContext.jsx';

const LABELS = {
    en: {
        header: 'Carbon Credit Eligibility',
        eligible: 'Eligible',
        notEligible: 'Not Eligible',
        farm: (n) => `Your ${n}-acre farm`,
        programs: '🇮🇳 Available India Programs',
    },
    hi: {
        header: 'कार्बन क्रेडिट पात्रता',
        eligible: 'पात्र है',
        notEligible: 'पात्र नहीं',
        farm: (n) => `आपका ${n} एकड़ का खेत`,
        programs: '🇮🇳 भारत में उपलब्ध कार्यक्रम',
    },
    mr: {
        header: 'कार्बन क्रेडिट पात्रता',
        eligible: 'पात्र आहे',
        notEligible: 'पात्र नाही',
        farm: (n) => `तुमचे ${n}-एकर शेत`,
        programs: '🇮🇳 भारतात उपलब्ध कार्यक्रम',
    },
    te: {
        header: 'కార్బన్ క్రెడిట్ అర్హత',
        eligible: 'అర్హత ఉంది',
        notEligible: 'అర్హత లేదు',
        farm: (n) => `మీ ${n} ఎకరాల పొలం`,
        programs: '🇮🇳 భారతదేశంలో అందుబాటులో ఉన్న కార్యక్రమాలు',
    },
    ta: {
        header: 'கார்பன் கிரெடிட் தகுதி',
        eligible: 'தகுதியானவர்',
        notEligible: 'தகுதியற்றவர்',
        farm: (n) => `உங்கள் ${n} ஏக்கர் நிலம்`,
        programs: '🇮🇳 இந்தியாவில் கிடைக்கும் திட்டங்கள்',
    },
    bn: {
        header: 'কার্বন ক্রেডিট যোগ্যতা',
        eligible: 'যোগ্য',
        notEligible: 'অযোগ্য',
        farm: (n) => `আপনার ${n} একরের জমি`,
        programs: '🇮🇳 ভারতে উপলব্ধ কার্যক্রম',
    },
};

// Curated India-specific carbon credit programs (bilingual per language)
const INDIA_PROGRAMS = [
    {
        nameEn: 'Indian Carbon Market (ICM)',
        name: {
            hi: 'भारतीय कार्बन बाज़ार (ICM)',
            mr: 'भारतीय कार्बन बाजार (ICM)',
            te: 'భారతీయ కార్బన్ మార్కెట్ (ICM)',
            ta: 'இந்திய கார்பன் சந்தை (ICM)',
        },
        tag: '🇮🇳 Govt. of India',
        desc: {
            en: 'Ministry of Environment & BEE regulated domestic carbon trading scheme.',
            hi: 'पर्यावरण मंत्रालय एवं BEE द्वारा विनियमित घरेलू कार्बन व्यापार योजना।',
            mr: 'पर्यावरण मंत्रालय आणि BEE नियमित देशांतर्गत कार्बन व्यापार योजना.',
            te: 'పర్యావరణ మంత్రిత్వ శాఖ మరియు BEE నిర్వహించే దేశీయ కార్బన్ ట్రేడింగ్ పథకం.',
            ta: 'சுற்றுச்சூழல் அமைச்சகம் மற்றும் BEE நடத்தும் உள்நாட்டு கார்பன் வர்த்தக திட்டம்.',
            bn: 'পরিবেশ মন্ত্রণালয় ও BEE নিয়ন্ত্রিত দেশীয় কার্বন ট্রেডিং স্কিম।',
        },
        color: '#f59e0b',
    },
    {
        nameEn: 'CCTS – Carbon Credit Trading Scheme',
        name: {
            hi: 'CCTS – कार्बन क्रेडिट ट्रेडिंग',
            mr: 'CCTS – कार्बन क्रेडिट ट्रेडिंग',
            te: 'CCTS – కార్బన్ క్రెడిట్ ట్రేడింగ్',
            ta: 'CCTS – கார்பன் கிரெடிட் வர்த்தகம்',
            bn: 'CCTS – কার্বন ক্রেডিট ট্রেডিং',
        },
        tag: '⚡ BEE India',
        desc: {
            en: 'Bureau of Energy Efficiency scheme — open to agricultural & forestry projects.',
            hi: 'ऊर्जा दक्षता ब्यूरो योजना — कृषि और वानिकी परियोजनाओं के लिए खुली।',
            mr: 'ऊर्जा कार्यक्षमता ब्युरो योजना — कृषी आणि वनीकरण प्रकल्पांसाठी खुली.',
            te: 'శక్తి సామర్థ్య బ్యూరో పథకం — వ్యవసాయ మరియు అటవీ ప్రాజెక్టులకు అందుబాటులో.',
            ta: 'ஆற்றல் திறன் பணியகத் திட்டம் — விவசாய மற்றும் வனவியல் திட்டங்களுக்கு திறந்தது.',
            bn: 'শক্তি দক্ষতা ব্যুরো স্কিম — কৃষি ও বনায়ন প্রকল্পের জন্য উন্মুক্ত।',
        },
        color: '#34d399',
    },
    {
        nameEn: 'Plan Vivo (Smallholder Scheme)',
        name: {
            hi: 'Plan Vivo (किसान योजना)',
            mr: 'Plan Vivo (शेतकरी योजना)',
            te: 'Plan Vivo (రైతు పథకం)',
            ta: 'Plan Vivo (விவசாயி திட்டம்)',
            bn: 'Plan Vivo (কৃষক প্রকল্প)',
        },
        tag: '🌱 Smallholders',
        desc: {
            en: 'Designed for smallholder farmers in India. Easiest to access for rural communities.',
            hi: 'भारत के छोटे किसानों के लिए विशेष रूप से बनाई गई। ग्रामीण समुदायों के लिए सबसे सुलभ।',
            mr: 'भारतातील लहान शेतकऱ्यांसाठी विशेषतः तयार केलेली. ग्रामीण समुदायांसाठी सर्वात सोपी.',
            te: 'భారతదేశంలో చిన్న రైతుల కోసం ప్రత్యేకంగా రూపొందించబడింది. గ్రామీణ సమాజానికి సులభంగా అందుబాటులో.',
            ta: 'இந்தியாவின் சிறு விவசாயிகளுக்காக வடிவமைக்கப்பட்டது. கிராமப்புற சமூகங்களுக்கு மிகவும் எளிது.',
            bn: 'ভারতের ক্ষুদ্র কৃষকদের জন্য বিশেষভাবে ডিজাইন করা হয়েছে। গ্রামীণ সম্প্রদায়ের জন্য সবচেয়ে সহজলভ্য।',
        },
        color: '#86efac',
    },
];

export default function CarbonCard({ eligible = true, farmSize = 3 }) {
    const { lang } = useLanguage();
    const L = LABELS[lang] || LABELS.en;

    return (
        <div style={{
            background: 'linear-gradient(135deg, #1a2e1a, #2d5016)',
            borderRadius: 16,
            padding: '1.5rem',
            boxShadow: 'var(--shadow)',
            position: 'relative',
            overflow: 'hidden',
        }}>
            {/* Gold radial glow */}
            <div style={{
                position: 'absolute', top: -40, right: -40,
                width: 200, height: 200, borderRadius: '50%',
                background: 'radial-gradient(circle, rgba(212,160,23,0.12), transparent 70%)',
                pointerEvents: 'none',
            }} />

            {/* Header */}
            <div style={{
                fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase',
                letterSpacing: '0.1em', color: 'rgba(255,255,255,0.4)',
                marginBottom: '1.2rem', position: 'relative', zIndex: 1,
            }}>
                🌍 {L.header}
            </div>

            {/* Eligibility badge */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: '1.4rem', position: 'relative', zIndex: 1 }}>
                <div style={{
                    width: 56, height: 56, borderRadius: '50%',
                    background: eligible ? 'linear-gradient(135deg,#4caf50,#8bc34a)' : 'rgba(255,255,255,0.12)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '1.8rem', flexShrink: 0,
                }}>
                    {eligible ? '✅' : '❌'}
                </div>
                <div>
                    <div style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: '1.4rem', fontWeight: 900, lineHeight: 1.2,
                        color: eligible ? 'var(--gold)' : 'rgba(255,255,255,0.5)',
                    }}>
                        {eligible ? L.eligible : L.notEligible}
                    </div>
                    <div style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.45)', marginTop: 2 }}>
                        {L.farm(farmSize)}
                    </div>
                </div>
            </div>

            {/* India-specific programs */}
            {eligible && (
                <>
                    <div style={{
                        fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase',
                        letterSpacing: '0.08em', color: 'rgba(255,255,255,0.35)',
                        marginBottom: '0.8rem', position: 'relative', zIndex: 1,
                    }}>
                        {L.programs}
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.7rem', position: 'relative', zIndex: 1 }}>
                        {INDIA_PROGRAMS.map(p => (
                            <div key={p.nameEn} style={{
                                background: 'rgba(255,255,255,0.06)',
                                borderRadius: 10,
                                padding: '10px 14px',
                                borderLeft: `3px solid ${p.color}`,
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                                    <span style={{ fontSize: '0.72rem', fontWeight: 700, color: p.color }}>
                                        {p.name[lang] || p.nameEn}
                                    </span>
                                    <span style={{
                                        fontSize: '0.6rem', fontWeight: 600,
                                        background: 'rgba(255,255,255,0.1)',
                                        color: 'rgba(255,255,255,0.5)',
                                        borderRadius: 20, padding: '1px 8px',
                                    }}>
                                        {p.tag}
                                    </span>
                                </div>
                                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', lineHeight: 1.4 }}>
                                    {p.desc[lang] || p.desc.en}
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}
        </div>
    );
}
