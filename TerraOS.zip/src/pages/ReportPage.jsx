import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { fetchReport } from "../services/api.js";
import { translateBatch } from "../services/translateService.js";
import SoilScoreGauge from "../components/SoilScoreGauge.jsx";
import NutrientCard from "../components/NutrientCard.jsx";
import PracticeAccordion from "../components/PracticeAccordion.jsx";
import CarbonCard from "../components/CarbonCard.jsx";
import BottomNav from "../components/BottomNav.jsx";
import TopNav from "../components/TopNav.jsx";

/* ── Helpers ── */
const fmtINR = (n) =>
  n !== undefined ? `₹${Number(n).toLocaleString("en-IN")}` : "—";
const STATUS_COLOR = {
  adequate: "ok",
  optimal: "ok",
  sufficient: "ok",
  normal: "ok",
  deficient: "low",
  low: "low",
  excess: "high",
  high: "high",
  critical: "critical",
};

/**
 * Maps the real API JSON structure to what each component expects.
 *
 * API shape (abbreviated):
 * {
 *   report_id, farmer_id, timestamp,
 *   farmer_data: { farmer_name, nitrogen, phosphorus, potassium, ph, crop_type, location, soil_type, farm_size_acres },
 *   npk_analysis: { npk_health_score, nitrogen_status, phosphorus_status, potassium_status, ph_assessment, fertilizer_recommendations, explanation },
 *   ecosystem_analysis: { inferred_micronutrients, organic_carbon_estimate, microbial_health, ecosystem_concerns, organic_amendments },
 *   suggestions: { overall_soil_score, soil_health_grade, priority_actions, crop_recommendations, regenerative_practices, farmer_friendly_summary },
 *   historical_analysis: { has_history, trend },
 *   carbon_analysis: { carbon_sequestration_potential, carbon_credit_income, carbon_program_eligibility, carbon_summary },
 *   summary: { soil_score, grade, top_action, carbon_income_potential_inr }
 * }
 */
export default function ReportPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { farmerId: ctxFarmerId, lastReport, updateLastReport } = useAuth();
  const { t, lang } = useLanguage();

  const [report, setReport] = useState(
    location.state?.report || lastReport || null,
  );
  const [loading, setLoading] = useState(!report);
  const [error, setError] = useState("");
  // Holds translated versions of all dynamic API text fields
  const [tx, setTx] = useState({});
  const [translating, setTranslating] = useState(false);

  const farmerId = location.state?.farmerId || ctxFarmerId;

  /* Fetch report if not already in state */
  useEffect(() => {
    if (report) return;
    if (!farmerId) {
      setError("No report data. Please analyze your soil first.");
      setLoading(false);
      return;
    }
    fetchReport(farmerId)
      .then((data) => {
        setReport(data);
        updateLastReport(data);
      })
      .catch((e) => setError(e.message || "Failed to load report."))
      .finally(() => setLoading(false));
  }, [farmerId]); // eslint-disable-line

  /* Translate all dynamic API content whenever the report or language changes */
  useEffect(() => {
    if (!report || lang === "en") {
      setTx({});
      return;
    }
    const r = (report.farmer_data || report.npk_analysis || report.suggestions)
      ? report
      : (report.full_report || report);
    const fd = r.farmer_data || {};
    const npkA = r.npk_analysis || {};
    const eco = r.ecosystem_analysis || {};
    const sug = r.suggestions || {};
    const carbA = r.carbon_analysis || {};
    const hist = r.historical_analysis || {};

    // Collect all string fields that come from the API
    const dynamicStrings = {
      farmerFriendlySummary: sug.farmer_friendly_summary || "",
      npkExplanation: npkA.explanation || "",
      phAssessment: npkA.ph_assessment || "",
      carbonSummary: carbA.carbon_summary || "",
      histMessage: hist.message || "",
      microbialHealth: eco.microbial_health || "",
      organicCarbon: eco.organic_carbon_estimate || "",
      cecEstimate: eco.cec_estimate || "",
      waterRetention: eco.water_retention || "",
      cropSuitability: sug.crop_recommendations?.current_crop_suitability || "",
      inputCostReduction: sug.input_cost_reduction || "",
      yieldImprovement: sug.expected_yield_improvement || "",
    };

    // Arrays and objects need special handling
    const priorityActions = sug.priority_actions || [];
    const fertRecs = npkA.fertilizer_recommendations || [];
    const practices = sug.regenerative_practices || [];
    const organicAmendments = eco.organic_amendments || [];
    const cropSuggested = sug.crop_recommendations?.suggested_crops || [];
    const intercroppingOptions =
      sug.crop_recommendations?.intercropping_options || [];
    const micronutrients = eco.inferred_micronutrients || null;

    setTranslating(true);
    const allPromises = [
      // Scalar strings
      translateBatch(dynamicStrings, lang),
      // Arrays → flatten to { '0': '...', '1': '...' } then re-split
      translateBatch(
        Object.fromEntries(priorityActions.map((s, i) => [i, s])),
        lang,
      ),
      translateBatch(Object.fromEntries(fertRecs.map((s, i) => [i, s])), lang),
      translateBatch(
        Object.fromEntries(
          practices
            .map((p, i) => [`practice_${i}`, p.practice || ""])
            .concat(
              practices.map((p, i) => [`benefit_${i}`, p.benefit || ""]),
              practices.map((p, i) => [`impl_${i}`, p.implementation || ""]),
            ),
        ),
        lang,
      ),
      translateBatch(
        Object.fromEntries(organicAmendments.map((s, i) => [i, s])),
        lang,
      ),
      translateBatch(
        Object.fromEntries(cropSuggested.map((s, i) => [i, s])),
        lang,
      ),
      translateBatch(
        Object.fromEntries(intercroppingOptions.map((s, i) => [i, s])),
        lang,
      ),
      micronutrients
        ? translateBatch(
            Object.fromEntries(
              Object.entries(micronutrients).map(([k, v]) => [k, String(v)]),
            ),
            lang,
          )
        : Promise.resolve({}),
    ];

    Promise.all(allPromises)
      .then(
        ([
          scalars,
          actions,
          ferts,
          practicesMap,
          amendments,
          suggested,
          intercrop,
          micro,
        ]) => {
          setTx({
            ...scalars,
            priorityActions: priorityActions.map(
              (_, i) => actions[i] || priorityActions[i],
            ),
            fertRecs: fertRecs.map((_, i) => ferts[i] || fertRecs[i]),
            practices: practices.map((p, i) => ({
              practice: practicesMap[`practice_${i}`] || p.practice,
              benefit: practicesMap[`benefit_${i}`] || p.benefit,
              implementation: practicesMap[`impl_${i}`] || p.implementation,
            })),
            organicAmendments: organicAmendments.map(
              (_, i) => amendments[i] || organicAmendments[i],
            ),
            suggestedCrops: cropSuggested.map(
              (_, i) => suggested[i] || cropSuggested[i],
            ),
            intercroppingOptions: intercroppingOptions.map(
              (_, i) => intercrop[i] || intercroppingOptions[i],
            ),
            micronutrients: micronutrients
              ? Object.fromEntries(
                  Object.keys(micronutrients).map((k) => [
                    k,
                    micro[k] || micronutrients[k],
                  ]),
                )
              : null,
          });
        },
      )
      .catch((err) => {
        console.warn("[ReportPage] translation batch failed:", err);
      })
      .finally(() => setTranslating(false));
  }, [report, lang]); // eslint-disable-line

  /* ── Loading ── */
  if (loading)
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "var(--mist)",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              border: "3px solid var(--mist)",
              borderTopColor: "var(--leaf)",
              animation: "spin 0.8s linear infinite",
              margin: "0 auto 1rem",
            }}
          />
          <div style={{ color: "var(--text-muted)" }}>
            {t("report.loading")}
          </div>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </div>
    );

  /* ── Error / no data ── */
  if (error || !report)
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "var(--mist)",
          padding: "2rem",
          gap: "1rem",
        }}
      >
        <div style={{ fontSize: "3rem" }}>⚠️</div>
        <div
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "1.4rem",
            fontWeight: 700,
          }}
        >
          {t("report.unavailable")}
        </div>
        <div
          style={{
            color: "var(--text-muted)",
            textAlign: "center",
            maxWidth: 340,
          }}
        >
          {error || t("report.nodata")}
        </div>
        <div
          style={{
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <button
            onClick={() => navigate("/analyze")}
            className="btn-primary"
            style={{ maxWidth: 200 }}
          >
            {t("report.btn.analyze")}
          </button>
          <button
            onClick={() => navigate("/home")}
            className="btn-primary"
            style={{
              maxWidth: 200,
              background: "white",
              color: "var(--moss)",
              border: "1.5px solid var(--border)",
            }}
          >
            {t("report.btn.home")}
          </button>
        </div>
      </div>
    );

  /* ──────────────────────────────────────────────
       Map nested API fields → local variables
       The normalizeReport() helper in api.js puts all deep fields inside
       full_report when the raw response is a summary wrapper row.
       Unwrap it here so the rest of the page logic always sees the full shape.
    ────────────────────────────────────────────── */
  // If farmer_data / npk_analysis / suggestions are missing at the top level,
  // the real data lives inside report.full_report — unwrap it.
  const r =
    report.farmer_data || report.npk_analysis || report.suggestions
      ? report
      : report.full_report || report;

  // ── DEBUG: log what the page actually resolved to ──
  console.log("[ReportPage] report top-level keys:", Object.keys(report || {}));
  console.log("[ReportPage] r top-level keys:", Object.keys(r || {}));
  console.log("[ReportPage] r.farmer_data:", r.farmer_data);
  console.log("[ReportPage] r.npk_analysis:", r.npk_analysis);
  console.log("[ReportPage] r.suggestions?.overall_soil_score:", r.suggestions?.overall_soil_score);
  console.log("[ReportPage] full report object r:", JSON.stringify(r, null, 2));

  const fd = r.farmer_data || {};
  const npkA = r.npk_analysis || {};
  const eco = r.ecosystem_analysis || {};
  const sug = r.suggestions || {};
  const hist = r.historical_analysis || {};
  const carbA = r.carbon_analysis || {};
  const sum = r.summary || {};

  // Score & grade
  const score = sum.soil_score ?? sug.overall_soil_score ?? 0;
  const grade = sum.grade ?? sug.soil_health_grade ?? "—";

  // Farmer details
  const farmerName = fd.farmer_name || r.farmer_id || "—";
  const location_ = fd.location || "";
  const cropType = fd.crop_type || "";
  const soilType = fd.soil_type || "";
  const farmSize = fd.farm_size_acres ?? "";
  const dateStr = (r.timestamp || r.generated_at || "").replace(
    /T(\d{2})-(\d{2})-(\d{2})Z/,
    "T$1:$2:$3Z",
  ); // fix non-standard timestamp
  const dateFormatted = dateStr
    ? new Date(dateStr).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
      })
    : "Today";

  // NPK — values from farmer_data, status from npk_analysis
  const npkItems = [
    { letter: "N", value: fd.nitrogen, statusRaw: npkA.nitrogen_status },
    { letter: "P", value: fd.phosphorus, statusRaw: npkA.phosphorus_status },
    { letter: "K", value: fd.potassium, statusRaw: npkA.potassium_status },
  ];
  const phValue = fd.ph ?? null;
  const phAssess = npkA.ph_assessment || "";

  // Priority actions (array of strings)
  const priorityActions = sug.priority_actions || [];

  // Fertilizer recs (array of strings)
  const fertRecs = npkA.fertilizer_recommendations || [];

  // Regenerative practices (array of { practice, benefit, implementation })
  const practices = sug.regenerative_practices || [];

  // Crop recs
  const cropRec = sug.crop_recommendations || null;

  // Ecosystem
  const micronutrients = eco.inferred_micronutrients || null;
  const organicCarbon = eco.organic_carbon_estimate || null;
  const microbialHealth = eco.microbial_health || null;
  const ecosystemConcerns = eco.ecosystem_concerns || [];
  const organicAmendments = eco.organic_amendments || [];

  // Carbon
  const carbSeq = carbA.carbon_sequestration_potential || {};
  const carbIncome = carbA.carbon_credit_income || {};
  const carbProg = carbA.carbon_program_eligibility || [];
  const carbSummary =
    tx.carbonSummary ||
    carbA.carbon_summary ||
    sug.farmer_friendly_summary ||
    "";
  const hasCarbonData = Object.keys(carbA).length > 0;

  // Dynamic (translated) arrays — fallback to raw API data when lang==='en' or translation pending
  const txPriorityActions = tx.priorityActions || priorityActions;
  const txFertRecs = tx.fertRecs || fertRecs;
  const txPractices = tx.practices || practices;
  const txOrganicAmendments = tx.organicAmendments || organicAmendments;
  const txMicronutrients = tx.micronutrients || micronutrients;
  const txSuggestedCrops = tx.suggestedCrops || cropRec?.suggested_crops || [];
  const txIntercroppingOptions =
    tx.intercroppingOptions || cropRec?.intercropping_options || [];

  return (
    <div
      className="page-with-topnav"
      style={{
        background: "var(--mist)",
        padding: "1.5rem",
        minHeight: "100vh",
        paddingBottom: 100,
      }}
    >
      {/* Desktop top nav */}
      <div style={{ display: "none" }} className="desktop-nav">
        <TopNav />
      </div>

      {/* ── Header ── */}
      <div
        style={{
          maxWidth: 760,
          margin: "0 auto 1.5rem",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "1rem",
          flexWrap: "wrap",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
          <button className="back-btn" onClick={() => navigate("/home")}>
            ←
          </button>
          <div>
            <div
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "1.2rem",
                fontWeight: 700,
              }}
            >
              {t("report.header.title")}
            </div>
            <div
              style={{
                fontSize: "0.78rem",
                color: "var(--text-muted)",
                fontFamily: "'DM Mono', monospace",
              }}
            >
              {dateFormatted}
              {location_ ? ` · ${location_}` : ""}
              {cropType ? ` · ${cropType}` : ""}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
          <button
            className="share-btn"
            onClick={() => alert("PDF export coming soon!")}
          >
            📄 {t("report.pdf")}
          </button>
          <button
            className="share-btn"
            onClick={() => {
              if (navigator.share)
                navigator.share({
                  title: "My TerraOS Soil Report",
                  text: `Soil Score: ${score}/100`,
                });
            }}
          >
            📤 {t("report.share")}
          </button>
        </div>
      </div>

      <div
        style={{
          maxWidth: 760,
          margin: "0 auto",
          display: "flex",
          flexDirection: "column",
          gap: "1.2rem",
        }}
      >
        {/* ── A: Overall Score ── */}
        <div className="report-card">
          <div
            style={{
              fontSize: "0.72rem",
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.1em",
              color: "var(--text-muted)",
              marginBottom: "1rem",
            }}
          >
            🏆 {t("report.score.label")}
          </div>
          <SoilScoreGauge score={score} size={100} strokeWidth={9} />
          <div
            style={{
              marginTop: "1.2rem",
              display: "flex",
              flexWrap: "wrap",
              gap: "0.8rem",
            }}
          >
            {[
              { label: t("report.farmer"), v: farmerName },
              { label: t("report.location"), v: location_ },
              { label: t("report.crop"), v: cropType },
              { label: t("report.soiltype"), v: soilType },
              {
                label: t("report.farmsize"),
                v: farmSize ? `${farmSize} ${t("report.acres")}` : null,
              },
              { label: t("report.score.grade"), v: grade },
            ]
              .filter((x) => x.v)
              .map(({ label, v }) => (
                <div
                  key={label}
                  style={{
                    background: "var(--mist)",
                    borderRadius: 8,
                    padding: "6px 12px",
                    fontSize: "0.8rem",
                  }}
                >
                  <span style={{ color: "var(--text-muted)" }}>{label}: </span>
                  <span
                    style={{ fontWeight: 600, color: "var(--text-primary)" }}
                  >
                    {v}
                  </span>
                </div>
              ))}
          </div>
          {sug.farmer_friendly_summary && (
            <div
              style={{
                marginTop: "1rem",
                padding: "12px 14px",
                background: "#f0f8ea",
                borderRadius: 10,
                fontSize: "0.85rem",
                color: "var(--moss)",
                lineHeight: 1.6,
              }}
            >
              💡 {tx.farmerFriendlySummary || sug.farmer_friendly_summary}
            </div>
          )}
        </div>

        {/* ── B: NPK & pH Status ── */}
        <div className="report-card">
          <div
            style={{
              fontSize: "0.72rem",
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.1em",
              color: "var(--text-muted)",
              marginBottom: "1rem",
            }}
          >
            ⚗️ {t("report.npk.title")}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: "0.8rem",
              marginBottom: "1rem",
            }}
          >
            {npkItems.map(({ letter, value, statusRaw }) =>
              value !== undefined ? (
                <NutrientCard
                  key={letter}
                  letter={letter}
                  value={`${value} kg/ha`}
                  status={STATUS_COLOR[statusRaw?.toLowerCase()] || "ok"}
                  recommendation={
                    statusRaw ? `${t("report.npk.status")}: ${statusRaw}` : ""
                  }
                />
              ) : null,
            )}
          </div>

          {/* NPK explanation */}
          {npkA.explanation && (
            <div
              style={{
                padding: "12px 14px",
                background: "#fafaf6",
                borderRadius: 10,
                fontSize: "0.82rem",
                color: "var(--text-secondary)",
                lineHeight: 1.6,
                marginBottom: "1rem",
              }}
            >
              {tx.npkExplanation || npkA.explanation}
            </div>
          )}

          {/* pH */}
          {phValue !== null && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12,
                padding: "12px 14px",
                background: "#f3e5f5",
                borderRadius: 10,
              }}
            >
              <div
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "1.6rem",
                  fontWeight: 700,
                  color: "#7b1fa2",
                  flexShrink: 0,
                }}
              >
                {parseFloat(phValue).toFixed(1)}
              </div>
              <div style={{ fontSize: "0.82rem", color: "#9c27b0" }}>
                <div style={{ fontWeight: 700, textTransform: "capitalize" }}>
                  {tx.phAssessment ||
                    phAssess ||
                    (phValue >= 6.5 && phValue <= 7.5
                      ? t("report.ph.neutral")
                      : phValue < 6.5
                        ? t("report.ph.acidic")
                        : t("report.ph.alkaline"))}
                </div>
                <div>
                  {phValue >= 6 && phValue <= 7.5
                    ? t("report.ph.advice.neutral")
                    : phValue < 6
                      ? t("report.ph.advice.acidic")
                      : t("report.ph.advice.alkaline")}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── C: Priority Actions ── */}
        {txPriorityActions.length > 0 && (
          <div className="report-card">
            <div
              style={{
                fontSize: "0.72rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                marginBottom: "1rem",
              }}
            >
              ⚡ {t("report.actions.title")}
            </div>
            <ul style={{ listStyle: "none" }}>
              {txPriorityActions.map((action, i) => (
                <li
                  key={i}
                  style={{
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 12,
                    padding: "10px 0",
                    borderBottom:
                      i < txPriorityActions.length - 1
                        ? "1px solid var(--border)"
                        : "none",
                  }}
                >
                  <div
                    style={{
                      width: 24,
                      height: 24,
                      background: "var(--leaf)",
                      color: "white",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "0.72rem",
                      fontWeight: 700,
                      flexShrink: 0,
                      marginTop: 1,
                    }}
                  >
                    {i + 1}
                  </div>
                  <div
                    style={{
                      fontSize: "0.88rem",
                      color: "var(--text-secondary)",
                      lineHeight: 1.5,
                    }}
                  >
                    {action}
                  </div>
                </li>
              ))}
            </ul>
            {txFertRecs.length > 0 && (
              <div
                style={{
                  marginTop: "1rem",
                  padding: "12px 14px",
                  background: "#fff8e1",
                  borderRadius: 10,
                }}
              >
                <div
                  style={{
                    fontSize: "0.72rem",
                    fontWeight: 700,
                    textTransform: "uppercase",
                    color: "#f57f17",
                    marginBottom: "0.5rem",
                  }}
                >
                  🧪 {t("report.fertilizer.title")}
                </div>
                {txFertRecs.map((r, i) => (
                  <div
                    key={i}
                    style={{
                      fontSize: "0.82rem",
                      color: "#795548",
                      lineHeight: 1.5,
                    }}
                  >
                    • {r}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── D: Crop Recommendations ── */}
        {cropRec && (
          <div className="report-card">
            <div
              style={{
                fontSize: "0.72rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                marginBottom: "1rem",
              }}
            >
              🌾 {t("report.crops.title")}
            </div>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: "0.6rem",
                marginBottom: "1rem",
              }}
            >
              {txSuggestedCrops.map((c, i) => (
                <span
                  key={i}
                  style={{
                    background: "#e8f5e9",
                    color: "var(--moss)",
                    borderRadius: 20,
                    padding: "4px 14px",
                    fontSize: "0.82rem",
                    fontWeight: 600,
                  }}
                >
                  {c}
                </span>
              ))}
            </div>
            {cropRec.current_crop_suitability && (
              <div
                style={{
                  fontSize: "0.82rem",
                  color: "var(--text-muted)",
                  marginBottom: "0.5rem",
                }}
              >
                {t("report.crop.suitability")}:{" "}
                <strong
                  style={{
                    color: "var(--text-primary)",
                    textTransform: "capitalize",
                  }}
                >
                  {tx.cropSuitability || cropRec.current_crop_suitability}
                </strong>
              </div>
            )}
            {txIntercroppingOptions.length > 0 && (
              <div style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>
                {t("report.crop.intercrop")}:&nbsp;
                <strong style={{ color: "var(--text-primary)" }}>
                  {txIntercroppingOptions.join(" | ")}
                </strong>
              </div>
            )}
            {(sug.input_cost_reduction || sug.expected_yield_improvement) && (
              <div
                style={{
                  display: "flex",
                  gap: "1rem",
                  marginTop: "1rem",
                  flexWrap: "wrap",
                }}
              >
                {sug.input_cost_reduction && (
                  <div
                    style={{
                      background: "#e3f2fd",
                      borderRadius: 10,
                      padding: "8px 14px",
                      fontSize: "0.82rem",
                      color: "#1565c0",
                    }}
                  >
                    {t("report.crop.cost")}:{" "}
                    <strong>
                      {tx.inputCostReduction || sug.input_cost_reduction}
                    </strong>
                  </div>
                )}
                {sug.expected_yield_improvement && (
                  <div
                    style={{
                      background: "#e8f5e9",
                      borderRadius: 10,
                      padding: "8px 14px",
                      fontSize: "0.82rem",
                      color: "#2e7d32",
                    }}
                  >
                    {t("report.crop.yield")}:{" "}
                    <strong>
                      {tx.yieldImprovement || sug.expected_yield_improvement}
                    </strong>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── E: Ecosystem Analysis ── */}
        {(txMicronutrients ||
          ecosystemConcerns.length > 0 ||
          organicCarbon) && (
          <div className="report-card">
            <div
              style={{
                fontSize: "0.72rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                marginBottom: "1rem",
              }}
            >
              🌿 {t("report.ecosystem.title")}
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "0.8rem",
                marginBottom: "1rem",
              }}
            >
              {[
                {
                  key: "report.eco.organic_carbon",
                  v: tx.organicCarbon || organicCarbon,
                },
                {
                  key: "report.eco.microbial",
                  v: tx.microbialHealth || microbialHealth,
                },
                {
                  key: "report.eco.cec",
                  v: tx.cecEstimate || eco.cec_estimate,
                },
                {
                  key: "report.eco.water",
                  v: tx.waterRetention || eco.water_retention,
                },
              ]
                .filter((x) => x.v)
                .map(({ key, v }) => (
                  <div
                    key={key}
                    style={{
                      background: "var(--mist)",
                      borderRadius: 10,
                      padding: "10px 12px",
                    }}
                  >
                    <div
                      style={{
                        fontSize: "0.68rem",
                        fontWeight: 700,
                        textTransform: "uppercase",
                        color: "var(--text-muted)",
                        marginBottom: 3,
                      }}
                    >
                      {t(key)}
                    </div>
                    <div
                      style={{
                        fontSize: "0.8rem",
                        color: "var(--text-secondary)",
                        lineHeight: 1.4,
                      }}
                    >
                      {v}
                    </div>
                  </div>
                ))}
            </div>

            {txMicronutrients && (
              <>
                <div
                  style={{
                    fontSize: "0.78rem",
                    fontWeight: 700,
                    color: "var(--text-secondary)",
                    marginBottom: "0.6rem",
                  }}
                >
                  {t("report.eco.micronutrients")}
                </div>
                {Object.entries(txMicronutrients).map(([k, v]) => {
                  const isDeficient =
                    String(v).toLowerCase().includes("deficient") ||
                    String(v).toLowerCase().includes("कमी");
                  return (
                    <div
                      key={k}
                      style={{
                        display: "flex",
                        alignItems: "flex-start",
                        gap: 8,
                        padding: "6px 0",
                        borderBottom: "1px solid var(--border)",
                      }}
                    >
                      <span
                        style={{
                          background: isDeficient ? "#fff3e0" : "#e8f5e9",
                          color: isDeficient ? "#e65100" : "#2e7d32",
                          borderRadius: 20,
                          padding: "1px 8px",
                          fontSize: "0.68rem",
                          fontWeight: 700,
                          textTransform: "capitalize",
                          flexShrink: 0,
                          marginTop: 2,
                        }}
                      >
                        {k}
                      </span>
                      <span
                        style={{
                          fontSize: "0.8rem",
                          color: "var(--text-secondary)",
                          lineHeight: 1.4,
                        }}
                      >
                        {v}
                      </span>
                    </div>
                  );
                })}
              </>
            )}

            {txOrganicAmendments.length > 0 && (
              <div style={{ marginTop: "1rem" }}>
                <div
                  style={{
                    fontSize: "0.72rem",
                    fontWeight: 700,
                    textTransform: "uppercase",
                    color: "var(--text-muted)",
                    marginBottom: "0.5rem",
                  }}
                >
                  {t("report.eco.amendments")}
                </div>
                <div
                  style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}
                >
                  {txOrganicAmendments.map((a, i) => (
                    <span
                      key={i}
                      style={{
                        background: "#f1f8e9",
                        color: "var(--leaf)",
                        borderRadius: 20,
                        padding: "3px 12px",
                        fontSize: "0.78rem",
                        fontWeight: 600,
                        textTransform: "capitalize",
                      }}
                    >
                      {a}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── F: Regenerative Practices ── */}
        {txPractices.length > 0 && (
          <div className="report-card">
            <div
              style={{
                fontSize: "0.72rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                marginBottom: "1rem",
              }}
            >
              🌱 {t("report.practices.title")}
            </div>
            {txPractices.map((p, i) => (
              <PracticeAccordion
                key={p.practice || i}
                icon="🌿"
                name={p.practice}
                benefit={p.benefit}
                howTo={p.implementation}
                defaultOpen={i === 0}
              />
            ))}
          </div>
        )}

        {/* ── G: Historical Trend ── */}
        {hist && (
          <div className="report-card">
            <div
              style={{
                fontSize: "0.72rem",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--text-muted)",
                marginBottom: "0.8rem",
              }}
            >
              📊 {t("report.history.title")}
            </div>
            <div
              style={{
                fontSize: "0.88rem",
                color: "var(--text-secondary)",
                lineHeight: 1.6,
              }}
            >
              {hist.has_history
                ? t("report.hist.trend")
                    .replace("{n}", hist.reports_analyzed)
                    .replace("{trend}", hist.trend?.replace(/_/g, " ") || "")
                : hist.message || t("report.hist.first")}
            </div>
          </div>
        )}

        {/* ── H: Carbon Credits ── */}
        {hasCarbonData && (
          <CarbonCard
            eligible={carbProg.length > 0}
            programs={carbProg}
            summary={carbSummary}
            farmSize={farmSize || 1}
          />
        )}

        {/* Carbon program eligibility pills */}
        {carbProg.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
            {carbProg.map((p) => (
              <span
                key={p}
                style={{
                  background: "rgba(45,80,22,0.1)",
                  color: "var(--moss)",
                  borderRadius: 20,
                  padding: "4px 14px",
                  fontSize: "0.78rem",
                  fontWeight: 600,
                  border: "1px solid rgba(45,80,22,0.2)",
                }}
              >
                ✓ {p}
              </span>
            ))}
          </div>
        )}

        {/* ── Actions ── */}
        <div
          style={{
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            paddingBottom: "1rem",
          }}
        >
          <button
            onClick={() => navigate("/analyze")}
            style={{
              flex: 1,
              minWidth: 140,
              padding: "14px",
              background: "var(--mist)",
              border: "1.5px solid var(--border)",
              borderRadius: 12,
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: 600,
              cursor: "pointer",
              color: "var(--text-primary)",
            }}
          >
            {t("report.btn.new")}
          </button>
          <button
            onClick={() => navigate("/history")}
            style={{
              flex: 1,
              minWidth: 140,
              padding: "14px",
              background: "var(--moss)",
              color: "white",
              border: "none",
              borderRadius: 12,
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {t("report.btn.history")}
          </button>
        </div>
      </div>

      <BottomNav />
      <style>{`
        @media (min-width: 768px) { .desktop-nav { display: block !important; } }
        @media (min-width: 768px) { div.report-page-root { padding-top: 80px !important; } }
        @media (max-width: 600px) {
          div[style*="grid-template-columns: repeat(3, 1fr)"] { grid-template-columns: 1fr 1fr !important; }
          div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
