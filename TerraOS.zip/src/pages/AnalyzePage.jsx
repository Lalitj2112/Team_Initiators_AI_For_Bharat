import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { analyzeSoil } from '../services/api.js';
import { translateText } from '../services/translateService.js';
import BottomNav from '../components/BottomNav.jsx';
import TopNav from '../components/TopNav.jsx';

// English value → stored in form state (sent to backend as-is)
// Native labels  → displayed in dropdown for non-English languages
const CROPS = [
    { en: 'Wheat', hi: '🌾 गेहूँ', mr: '🌾 गहू', te: '🌾 గోధుమలు', ta: '🌾 கோதுமை', bn: '🌾 গম' },
    { en: 'Rice', hi: '🌾 चावल', mr: '🌾 तांदूळ', te: '🌾 వరి', ta: '🌾 அரிசி', bn: '🌾 ধান' },
    { en: 'Cotton', hi: '🌿 कपास', mr: '🌿 कापूस', te: '🌿 పత్తి', ta: '🌿 பருத்தி', bn: '🌿 তুলা' },
    { en: 'Sugarcane', hi: '🎋 गन्ना', mr: '🎋 उसाका', te: '🎋 చెరకు', ta: '🎋 கரும்பு', bn: '🎋 আখ' },
    { en: 'Maize', hi: '🌽 मक्का', mr: '🌽 मका', te: '🌽 మొక్కజొన్న', ta: '🌽 மக்கச்சோளம்', bn: '🌽 ভুট্টाभुट्टी' },
    { en: 'Other', hi: 'अन्य', mr: 'इतर', te: 'ఇతరాలు', ta: 'மற்றவை', bn: 'অন্য' },
];
const SOIL_TYPES = [
    { en: 'Black Cotton', hi: 'काली मिट्टी', mr: 'काळी माती', te: 'నల్ల మడ్డి', ta: 'கறுப்பு மண்', bn: 'কালো মাটি' },
    { en: 'Red Laterite', hi: 'लाल लेटराइट', mr: 'लाल लॅटेराइट', te: 'ఎర్ర లెటరైట్', ta: 'சிவப்பு லாடேரைட்', bn: 'লাল ল্যাটেরাইট' },
    { en: 'Alluvial', hi: 'जलोढ़ मिट्टी', mr: 'गाळाची माती', te: 'జలోఢ మడ్డి', ta: 'ஆற்றலூடியல்', bn: 'ইলিউভিয়াল' },
    { en: 'Sandy Loam', hi: 'बलुई दोमट', mr: 'वालुकमय । दोमट', te: 'ఇసుకని మేళము', ta: 'மணல்கல் வண்டல்', bn: 'বালি দোআঁশ' },
    { en: 'Clay', hi: 'चिकनी मिट्टी', mr: 'चिकण माती', te: 'మట్టి మడ్డి', ta: 'சிக்குநிலம்', bn: 'দোআঁশ মাটি' },
];

export default function AnalyzePage() {
    const navigate = useNavigate();
    const { currentUser, updateFarmerId } = useAuth();
    const { t, lang } = useLanguage();
    const [translatingInputs, setTranslatingInputs] = useState(false);

    const [form, setForm] = useState({
        farmer_name: currentUser?.name || '',
        location: '',
        crop_planned: CROPS[0].en,
        farm_size: '',
        soil_type: SOIL_TYPES[0].en,
        nitrogen: '',
        phosphorus: '',
        potassium: '',
        ph: 6.8,
        organic_carbon: '',
        ec: '',
        zinc: '',
        boron: '',
        sulfur: '',
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

    const getNpkBadge = (key) => {
        const v = parseFloat(form[key]);
        if (isNaN(v)) return null;
        if (key === 'nitrogen') return v < 280 ? 'Low' : v > 560 ? 'High' : 'Adequate';
        if (key === 'phosphorus') return v < 11 ? 'Low' : v > 22 ? 'High' : 'Adequate';
        if (key === 'potassium') return v < 118 ? 'Low' : v > 280 ? 'High' : 'Adequate';
        return null;
    };
    const badgeClass = (badge) => badge === 'Adequate' ? 'badge-ok' : badge === 'Low' ? 'badge-low' : 'badge-high';

    const handleSubmit = async () => {
        const required = ['farmer_name', 'location', 'crop_planned', 'farm_size', 'soil_type', 'nitrogen', 'phosphorus', 'potassium', 'organic_carbon'];
        const empty = required.find(k => !String(form[k]).trim());
        if (empty) { setError(`Please fill in all required fields (${empty.replace('_', ' ')}).`); return; }

        setError(''); setLoading(true);
        try {
            // If user typed in Hindi, translate text fields to English for the AI backend
            let farmer_name = form.farmer_name.trim();
            let location = form.location.trim();
            if (lang !== 'en') {
                setTranslatingInputs(true);
                [farmer_name, location] = await Promise.all([
                    translateText(farmer_name, 'en'),
                    translateText(location, 'en'),
                ]);
                setTranslatingInputs(false);
            }

            // Strip emoji prefix from crop name for the backend (already English)
            const cleanCrop = form.crop_planned.replace(/^[\p{Emoji}\s]+/u, '').trim() || form.crop_planned;
            const payload = {
                ...form,
                farmer_name,
                location,
                crop_type: cleanCrop,
                crop_planned: cleanCrop,
                ph: parseFloat(form.ph),
                nitrogen: parseFloat(form.nitrogen),
                phosphorus: parseFloat(form.phosphorus),
                potassium: parseFloat(form.potassium),
                farm_size: parseFloat(form.farm_size),
                organic_carbon: parseFloat(form.organic_carbon),
                ec: form.ec ? parseFloat(form.ec) : undefined,
                zinc: form.zinc ? parseFloat(form.zinc) : undefined,
                boron: form.boron ? parseFloat(form.boron) : undefined,
                sulfur: form.sulfur ? parseFloat(form.sulfur) : undefined,
            };
            const submittedAt = Date.now();
            const res = await analyzeSoil(payload);
            updateFarmerId(res.farmer_id);
            navigate('/loading', { state: { farmerId: res.farmer_id, submittedAt, executionId: res.execution_id } });
        } catch (e) {
            setError(e.message || 'Analysis failed. Please try again.');
            setTranslatingInputs(false);
        } finally {
            setLoading(false);
        }
    };

    const inputCard = (title, children) => (
        <div style={{ background: 'white', borderRadius: 20, padding: '2rem', boxShadow: 'var(--shadow)', maxWidth: 700, margin: '0 auto 1.5rem' }}>
            <div className="section-title"><div className="section-dot" />{title}</div>
            {children}
        </div>
    );

    const label = (text, hint) => (
        <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            {text} {hint && <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem', textTransform: 'none', letterSpacing: 0 }}>({hint})</span>}
        </label>
    );

    return (
        <div className="page-with-topnav" style={{ background: 'var(--mist)', minHeight: '100vh', padding: '1.5rem', paddingBottom: 100 }}>
            {/* Desktop top nav */}
            <div style={{ display: 'none' }} className="desktop-nav"><TopNav /></div>

            {/* Header */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <button className="back-btn" onClick={() => navigate('/home')}>←</button>
                <div>
                    <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.3rem', fontWeight: 700, color: 'var(--text-primary)' }}>{t('analyze.header.title')}</h2>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{t('analyze.header.sub')}</p>
                </div>
            </div>

            {/* Farmer info */}
            {inputCard(t('analyze.section.farmer'), (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <div>
                        {label(t('analyze.field.name'))}
                        <input className="form-input" value={form.farmer_name} onChange={e => set('farmer_name', e.target.value)} placeholder="Your full name" />
                    </div>
                    <div>
                        {label(t('analyze.field.location'))}
                        <input className="form-input" value={form.location} onChange={e => set('location', e.target.value)} placeholder="e.g. Pune, Maharashtra" />
                    </div>
                    <div>
                        {label(t('analyze.field.crop'))}
                        <select className="form-select" value={form.crop_planned} onChange={e => set('crop_planned', e.target.value)}>
                            {CROPS.map(c => (
                                <option key={c.en} value={c.en}>
                                    {lang !== 'en' ? (c[lang] || `🌾 ${c.en}`) : `🌾 ${c.en}`}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        {label(t('analyze.field.farmsize'), t('analyze.field.farmsize.hint'))}
                        <input className="form-input" type="number" min="0.1" step="0.1" value={form.farm_size} onChange={e => set('farm_size', e.target.value)} placeholder="e.g. 3" />
                    </div>
                    <div style={{ gridColumn: '1/-1' }}>
                        {label(t('analyze.field.soiltype'))}
                        <select className="form-select" value={form.soil_type} onChange={e => set('soil_type', e.target.value)}>
                            {SOIL_TYPES.map(s => (
                                <option key={s.en} value={s.en}>
                                    {lang !== 'en' ? (s[lang] || s.en) : s.en}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            ))}

            {/* NPK Values */}
            {inputCard(t('analyze.section.npk'), (
                <>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                        {[
                            { key: 'nitrogen', name: t('analyze.field.nitrogen'), hint: '<280 low · 280–560 medium · >560 high' },
                            { key: 'phosphorus', name: t('analyze.field.phosphorus'), hint: '<11 low · 11–22 medium · >22 high' },
                            { key: 'potassium', name: t('analyze.field.potassium'), hint: '<118 low · 118–280 medium · >280 high' },
                        ].map(({ key, name, hint }) => {
                            const badge = getNpkBadge(key);
                            return (
                                <div key={key}>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                                        <span style={{ fontSize: '0.82rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)' }}>{name}</span>
                                        <span style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.7rem', color: 'var(--text-muted)' }}>kg/ha</span>
                                    </div>
                                    <input className="npk-input" type="number" min="0" value={form[key]} onChange={e => set(key, e.target.value)} placeholder="e.g. 140" />
                                    {badge && <div style={{ marginTop: 4 }}><span className={`npk-badge ${badgeClass(badge)}`}>{badge}</span></div>}
                                    <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: 2 }}>{hint}</div>
                                </div>
                            );
                        })}
                    </div>

                    {/* pH Slider */}
                    <div style={{ marginTop: '1.2rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                            <div>
                                <div style={{ fontSize: '0.82rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-secondary)' }}>{t('analyze.field.ph')}</div>
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{t('analyze.ph.acidic')} ← {t('analyze.ph.neutral')} → {t('analyze.ph.alkaline')}</div>
                            </div>
                            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.6rem', fontWeight: 700, color: 'var(--leaf)' }}>
                                {parseFloat(form.ph).toFixed(1)}
                            </div>
                        </div>
                        <input
                            className="ph-slider"
                            type="range" min="0" max="14" step="0.1"
                            value={form.ph}
                            onChange={e => set('ph', e.target.value)}
                        />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: 6, fontFamily: "'DM Mono', monospace" }}>
                            <span>0 ({t('analyze.ph.acidic')})</span><span>7 ({t('analyze.ph.neutral')})</span><span>14 ({t('analyze.ph.alkaline')})</span>
                        </div>
                    </div>
                </>
            ))}

            {/* Other Soil Params */}
            {inputCard(t('analyze.section.organic'), (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <div>
                        {label(t('analyze.field.oc'))}
                        <input className="form-input" type="number" min="0" max="5" step="0.01" value={form.organic_carbon} onChange={e => set('organic_carbon', e.target.value)} placeholder="e.g. 0.8" />
                    </div>
                    <div>
                        {label(t('analyze.field.ec'), t('analyze.field.optional'))}
                        <input className="form-input" type="number" min="0" step="0.01" value={form.ec} onChange={e => set('ec', e.target.value)} placeholder="e.g. 0.4" />
                    </div>
                    <div>
                        {label(t('analyze.field.zinc'), t('analyze.field.optional'))}
                        <input className="form-input" type="number" min="0" step="0.01" value={form.zinc} onChange={e => set('zinc', e.target.value)} placeholder="e.g. 1.2" />
                    </div>
                    <div>
                        {label(t('analyze.field.boron'), t('analyze.field.optional'))}
                        <input className="form-input" type="number" min="0" step="0.01" value={form.boron} onChange={e => set('boron', e.target.value)} placeholder="e.g. 0.5" />
                    </div>
                    <div style={{ gridColumn: '1/-1' }}>
                        {label(t('analyze.field.sulfur'), t('analyze.field.optional'))}
                        <input className="form-input" type="number" min="0" step="0.01" value={form.sulfur} onChange={e => set('sulfur', e.target.value)} placeholder="e.g. 10" />
                    </div>
                </div>
            ))}

            {/* Error + Submit */}
            <div style={{ maxWidth: 700, margin: '0 auto' }}>
                {error && (
                    <div style={{ background: '#fff3f3', border: '1px solid rgba(200,50,50,0.2)', borderRadius: 8, padding: '10px 14px', fontSize: '0.85rem', color: '#c62828', marginBottom: '1rem' }}>
                        ⚠️ {error}
                    </div>
                )}
                <button
                    className="submit-btn"
                    onClick={handleSubmit}
                    disabled={loading}
                >
                    {translatingInputs
                        ? `🔄 ${t('analyze.btn.translating') || 'Translating...'}`
                        : loading ? `⏳ ${t('analyze.btn.loading')}` : t('analyze.btn.submit')
                    }
                </button>
            </div>

            <BottomNav />

            <style>{`
        @media (min-width: 768px) { .desktop-nav { display: block !important; } }
        @media (min-width: 768px) { .analyze-page-inner { padding-top: 80px !important; } }
        @media (max-width: 640px) {
          div[style*="grid-template-columns: 1fr 1fr 1fr"] { grid-template-columns: 1fr !important; }
          div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
        </div>
    );
}
