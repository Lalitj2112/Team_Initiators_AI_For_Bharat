import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signUp, signIn, signOut, confirmSignUp, resendSignUpCode } from 'aws-amplify/auth';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';

const STATS = [
    { num: '₹35K+', label: 'Intelligence value' },
    { num: '60s', label: 'Analysis time' },
    { num: '5', label: 'AI agents' },
];

export default function LoginPage() {
    const navigate = useNavigate();
    const { checkAuth } = useAuth();
    const { t, lang, setLang } = useLanguage();

    // step: 'login' | 'register' | 'verify'
    const [step, setStep] = useState('login');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [otp, setOtp] = useState(['', '', '', '', '', '']);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [successMsg, setSuccessMsg] = useState('');
    const [resendSec, setResendSec] = useState(0);
    const [showPass, setShowPass] = useState(false);
    const otpRefs = useRef([]);

    // Countdown timer for resend
    useEffect(() => {
        if (resendSec <= 0) return;
        const t = setInterval(() => setResendSec(s => s - 1), 1000);
        return () => clearInterval(t);
    }, [resendSec]);

    /* ── SIGN IN (existing user) ── */
    const handleSignIn = async () => {
        if (!email.trim() || !password.trim()) { setError('Please enter your email and password.'); return; }
        setError(''); setSuccessMsg(''); setLoading(true);
        try {
            // Clear any stale Cognito session before signing in
            try { await signOut(); } catch (_) { /* ignore if no session */ }
            await signIn({ username: email, password });
            await checkAuth();
            navigate('/home');
        } catch (e) {
            if (e.name === 'UserNotConfirmedException') {
                // User exists but hasn't verified email yet — send OTP
                await resendSignUpCode({ username: email });
                setStep('verify');
                setResendSec(30);
            } else if (e.name === 'UserNotFoundException') {
                setError('No account found. Please register first.');
            } else {
                setError(e.message || 'Sign in failed. Please check your credentials.');
            }
        } finally {
            setLoading(false);
        }
    };

    /* ── REGISTER (new user) ── */
    const handleRegister = async () => {
        if (!name.trim() || !email.trim() || !password.trim()) { setError('Please fill all fields.'); return; }
        if (password.length < 8) { setError('Password must be at least 8 characters.'); return; }
        setError(''); setLoading(true);
        try {
            await signUp({
                username: email,
                password,
                options: { userAttributes: { email, name } },
            });
            setStep('verify');
            setResendSec(30);
        } catch (e) {
            if (e.name === 'UsernameExistsException') {
                setError('Account already exists. Please sign in instead.');
            } else {
                setError(e.message || 'Registration failed. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    /* ── VERIFY EMAIL OTP (new users only) ── */
    const handleVerify = async () => {
        const code = otp.join('');
        if (code.length < 6) { setError('Please enter the 6-digit code.'); return; }
        setError(''); setLoading(true);
        try {
            await confirmSignUp({ username: email, confirmationCode: code });
            // Show success notification and redirect to login step
            setSuccessMsg('✅ Account verified successfully! Please sign in to continue.');
            setStep('login');
            setOtp(['', '', '', '', '', '']);
            setPassword('');
        } catch (e) {
            setError(e.message || 'Invalid code. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    /* ── RESEND OTP ── */
    const handleResend = async () => {
        if (resendSec > 0) return;
        setLoading(true);
        try {
            await resendSignUpCode({ username: email });
            setResendSec(30);
            setOtp(['', '', '', '', '', '']);
            setError('');
        } catch (e) { setError(e.message); }
        finally { setLoading(false); }
    };

    const handleOtpInput = (i, val) => {
        if (!/^\d?$/.test(val)) return;
        const next = [...otp]; next[i] = val;
        setOtp(next);
        if (val && i < 5) otpRefs.current[i + 1]?.focus();
    };

    const handleOtpKey = (i, e) => {
        if (e.key === 'Backspace' && !otp[i] && i > 0) otpRefs.current[i - 1]?.focus();
    };

    return (
        <div style={{
            minHeight: '100vh',
            display: 'grid',
            gridTemplateColumns: 'clamp(0px,50%,520px) 1fr',
        }}>
            {/* ─── LEFT VISUAL PANEL ─── */}
            <div style={{
                background: 'linear-gradient(160deg, var(--moss) 0%, var(--carbon) 100%)',
                position: 'relative',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                padding: '4rem',
            }}
                className="login-visual-panel"
            >
                {/* Radial glows */}
                <div style={{
                    position: 'absolute', top: -60, right: -60,
                    width: 400, height: 400, borderRadius: '50%',
                    background: 'radial-gradient(circle, rgba(139,195,74,0.15), transparent 70%)',
                    pointerEvents: 'none',
                }} />
                <div style={{
                    position: 'absolute', bottom: -80, left: -40,
                    width: 300, height: 300, borderRadius: '50%',
                    background: 'radial-gradient(circle, rgba(212,160,23,0.1), transparent 70%)',
                    pointerEvents: 'none',
                }} />

                {/* Tagline */}
                <div style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: 'clamp(2rem, 4vw, 3rem)',
                    fontWeight: 900,
                    color: 'white',
                    lineHeight: 1.1,
                    marginBottom: '1.5rem',
                    position: 'relative', zIndex: 1,
                }}>
                    {t('login.hero.title')}
                </div>

                <p style={{
                    color: 'rgba(255,255,255,0.65)',
                    fontSize: '1rem',
                    lineHeight: 1.7,
                    maxWidth: 360,
                    position: 'relative', zIndex: 1,
                }}>
                    {t('login.hero.subtitle')}
                </p>

                {/* Stats */}
                <div style={{ display: 'flex', gap: '2rem', marginTop: '3rem', position: 'relative', zIndex: 1 }}>
                    {STATS.map(({ num, label }) => (
                        <div key={label}>
                            <div style={{
                                fontFamily: "'Playfair Display', serif",
                                fontSize: '1.8rem', fontWeight: 700,
                                color: 'var(--lime)',
                            }}>{num}</div>
                            <div style={{
                                fontSize: '0.75rem',
                                color: 'rgba(255,255,255,0.5)',
                                textTransform: 'uppercase',
                                letterSpacing: '0.08em',
                            }}>{label}</div>
                        </div>
                    ))}
                </div>

                {/* Soil Layers */}
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 120 }}>
                    <div className="soil-layer soil-layer-1" />
                    <div className="soil-layer soil-layer-2" />
                    <div className="soil-layer soil-layer-3" />
                </div>
            </div>

            {/* ─── RIGHT FORM PANEL ─── */}
            <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '3rem 2rem',
                background: 'var(--cream)',
                minHeight: '100vh',
                position: 'relative',
            }}>
                {/* ── Language dropdown (top-right of form) ── */}
                <div style={{ position: 'absolute', top: '1.2rem', right: '1.2rem' }}>
                    <select
                        value={lang}
                        onChange={e => setLang(e.target.value)}
                        style={{
                            padding: '6px 12px',
                            borderRadius: 20,
                            border: '1.5px solid var(--moss)',
                            background: 'white',
                            color: 'var(--moss)',
                            fontFamily: "'DM Sans', sans-serif",
                            fontSize: '0.82rem',
                            fontWeight: 700,
                            cursor: 'pointer',
                            outline: 'none',
                            boxShadow: '0 2px 8px rgba(45,80,22,0.12)',
                            appearance: 'none',
                            paddingRight: 28,
                            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%232d5016'/%3E%3C/svg%3E")`,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'right 10px center',
                        }}
                    >
                        <option value="en">🌐 English</option>
                        <option value="hi">🇮🇳 हिन्दी</option>
                        <option value="mr">🇮🇳 मराठी</option>
                        <option value="te">🇮🇳 తెలుగు</option>
                        <option value="ta">🇮🇳 தமிழ்</option>
                        <option value="bn">🇮🇳 বাংলা</option>
                    </select>
                </div>

                <div style={{ width: '100%', maxWidth: 400 }}>
                    {/* Logo */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '2.5rem' }}>
                        <div className="leaf-shape" style={{ width: 44, height: 44, fontSize: 20 }}>
                            <span>🌿</span>
                        </div>
                        <span style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: '1.6rem', fontWeight: 700,
                            color: 'var(--moss)',
                        }}>TerraOS</span>
                    </div>

                    {step === 'verify' ? (
                        /* ── STEP: Email Verification OTP (new users only) ── */
                        <>
                            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.4rem' }}>
                                {t('login.verify.title')}
                            </h2>
                            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '2rem' }}>
                                {t('login.verify.sub')} <strong>{email}</strong>
                            </p>

                            <div style={{ marginBottom: '1.2rem' }}>
                                <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                    {t('login.otp.label')}
                                </label>
                                <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
                                    {otp.map((digit, i) => (
                                        <input
                                            key={i}
                                            ref={el => otpRefs.current[i] = el}
                                            className={`otp-box${digit ? ' filled' : ''}`}
                                            type="text"
                                            maxLength={1}
                                            placeholder="·"
                                            value={digit}
                                            onChange={e => handleOtpInput(i, e.target.value)}
                                            onKeyDown={e => handleOtpKey(i, e)}
                                        />
                                    ))}
                                </div>
                            </div>

                            {error && <div style={{ background: '#fff3f3', border: '1px solid rgba(200,50,50,0.2)', borderRadius: 8, padding: '10px 14px', fontSize: '0.82rem', color: '#c62828', marginBottom: '1rem' }}>⚠️ {error}</div>}

                            <button className="btn-primary" onClick={handleVerify} disabled={loading}>
                                {loading ? t('login.btn.loading') : t('login.btn.verify')}
                            </button>

                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: '1rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                                {t('login.otp.nocode')}
                                <span onClick={handleResend} style={{ color: resendSec > 0 ? 'var(--text-muted)' : 'var(--leaf)', cursor: resendSec > 0 ? 'default' : 'pointer', fontWeight: 500 }}>
                                    {t('login.resend.btn')}
                                </span>
                                {resendSec > 0 && <span>({resendSec}s)</span>}
                            </div>
                            <button onClick={() => { setStep('register'); setError(''); setOtp(['', '', '', '', '', '']); }} style={{ display: 'block', margin: '0.8rem auto 0', background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: '0.82rem', cursor: 'pointer' }}>
                                {t('login.otp.back')}
                            </button>
                        </>
                    ) : (
                        /* ── STEP: Login / Register tabs ── */
                        <>
                            {/* Tab switcher */}
                            <div style={{ display: 'flex', background: 'var(--mist)', borderRadius: 10, padding: 4, marginBottom: '1.8rem', gap: 4 }}>
                                {(['login', 'register']).map(tab => (
                                    <button
                                        key={tab}
                                        onClick={() => { setStep(tab); setError(''); }}
                                        style={{
                                            flex: 1,
                                            padding: '8px 0',
                                            borderRadius: 8,
                                            border: 'none',
                                            cursor: 'pointer',
                                            fontFamily: "'DM Sans', sans-serif",
                                            fontSize: '0.88rem',
                                            fontWeight: 600,
                                            transition: 'all 0.2s',
                                            background: step === tab ? 'white' : 'transparent',
                                            color: step === tab ? 'var(--moss)' : 'var(--text-muted)',
                                            boxShadow: step === tab ? 'var(--shadow)' : 'none',
                                        }}
                                    >
                                        {tab === 'login' ? `🔑 ${t('login.tab.signin')}` : `🌱 ${t('login.tab.register')}`}
                                    </button>
                                ))}
                            </div>

                            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.4rem' }}>
                                {step === 'login' ? t('login.welcome') : t('login.create.title')}
                            </h2>
                            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.8rem' }}>
                                {step === 'login' ? t('login.welcome.sub') : t('login.create.sub')}
                            </p>

                            {/* Name — register only */}
                            {step === 'register' && (
                                <div style={{ marginBottom: '1.2rem' }}>
                                    <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{t('login.field.name')}</label>
                                    <input className="form-input" type="text" placeholder="Ramesh Kumar" value={name} onChange={e => setName(e.target.value)} />
                                </div>
                            )}

                            {/* Email */}
                            <div style={{ marginBottom: '1.2rem' }}>
                                <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{t('login.field.email')}</label>
                                <input className="form-input" type="email" placeholder="ramesh@example.com" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && document.querySelector('#password-input')?.focus()} />
                            </div>

                            {/* Password */}
                            <div style={{ marginBottom: '1.2rem' }}>
                                <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                                    {t('login.field.password')}
                                    {step === 'register' && <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem', textTransform: 'none', letterSpacing: 0, marginLeft: 6 }}>{t('login.pass.hint')}</span>}
                                </label>
                                <div style={{ position: 'relative' }}>
                                    <input
                                        id="password-input"
                                        className="form-input no-reveal"
                                        type={showPass ? 'text' : 'password'}
                                        placeholder="••••••••"
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && (step === 'login' ? handleSignIn() : handleRegister())}
                                        style={{ paddingRight: 44 }}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPass(v => !v)}
                                        style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '1rem' }}
                                    >
                                        {showPass ? '🙈' : '👁️'}
                                    </button>
                                </div>
                            </div>

                            {successMsg && (
                                <div style={{ background: 'linear-gradient(135deg, #e8f5e9, #f1f8e9)', border: '1px solid rgba(76,175,80,0.35)', borderRadius: 10, padding: '12px 16px', fontSize: '0.875rem', color: '#2e7d32', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: 8, boxShadow: '0 2px 8px rgba(76,175,80,0.12)', animation: 'fadeInDown 0.4s ease' }}>
                                    <span style={{ fontSize: '1.1rem' }}>✅</span>
                                    <span style={{ fontWeight: 500 }}>Account verified successfully!</span>
                                    <span style={{ color: '#388e3c', fontSize: '0.82rem', marginLeft: 2 }}>Please sign in to continue.</span>
                                </div>
                            )}
                            {error && <div style={{ background: '#fff3f3', border: '1px solid rgba(200,50,50,0.2)', borderRadius: 8, padding: '10px 14px', fontSize: '0.82rem', color: '#c62828', marginBottom: '1rem' }}>⚠️ {error}</div>}

                            <button
                                className="btn-primary"
                                onClick={step === 'login' ? handleSignIn : handleRegister}
                                disabled={loading}
                            >
                                {loading
                                    ? t('login.btn.loading')
                                    : (step === 'login' ? t('login.btn.signin') : t('login.btn.register'))
                                }
                            </button>

                            {step === 'login' && (
                                <p style={{ textAlign: 'center', marginTop: '1rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                                    {t('login.new.farmer')}{' '}
                                    <span onClick={() => { setStep('register'); setError(''); }} style={{ color: 'var(--leaf)', cursor: 'pointer', fontWeight: 500 }}>
                                        {t('login.create.link')}
                                    </span>
                                </p>
                            )}
                        </>
                    )}

                </div>
            </div>

            {/* Mobile: hide left panel */}
            <style>{`
        @media (max-width: 768px) {
          .login-visual-panel { display: none !important; }
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
        @keyframes fadeInDown {
          from { opacity: 0; transform: translateY(-8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
        </div>
    );
}
