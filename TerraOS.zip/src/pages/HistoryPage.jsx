import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { fetchAllReports } from '../services/api.js';
import BottomNav from '../components/BottomNav.jsx';
import TopNav from '../components/TopNav.jsx';

const getScoreColor = (s) => s >= 80 ? '#5A9E3A' : s >= 60 ? '#3E7B27' : '#F59E0B';

const fmtDate = (ts) => {
    if (!ts) return null;
    // Fix non-standard timestamps using dashes instead of colons in time part
    const fixed = String(ts).replace(/T(\d{2})-(\d{2})-(\d{2})/, 'T$1:$2:$3');
    const d = new Date(fixed);
    return isNaN(d) ? null : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
};

/**
 * Aggressively dig through every known path in the report object to get display values.
 * Works whether the API returns: flat summary rows, full S3 JSON, or full_report-nested objects.
 */
function getReportDisplay(r) {
    // The full nested data may be at r, r.full_report, or unparsed string
    let full = r;
    if (r.full_report) {
        full = typeof r.full_report === 'string' ? (() => { try { return JSON.parse(r.full_report); } catch { return r; } })() : r.full_report;
    }

    const fd = full.farmer_data || r.farmer_data || {};
    const sug = full.suggestions || r.suggestions || {};
    const sum = full.summary || r.summary || {};

    // Score — try every possible path
    const score = (
        (r.soil_score > 0 && r.soil_score) ||
        (sum.soil_score > 0 && sum.soil_score) ||
        sug.overall_soil_score ||
        0
    );

    // Grade
    const grade = (
        (r.grade && r.grade !== '-' && r.grade !== '\u2014' && r.grade) ||
        (sum.grade && sum.grade !== '\u2014' && sum.grade) ||
        sug.soil_health_grade ||
        '\u2014'
    );

    // Crop
    const crop = (
        (r.crop_type && r.crop_type !== 'Unknown' && r.crop_type) ||
        fd.crop_type || fd.crop_planned || full.crop_type || 'Soil Report'
    );

    // Date — try every timestamp variant
    const rawTs = r.timestamp || full.timestamp || full.generated_at || r.generated_at || '';
    const date = fmtDate(rawTs) || 'N/A';

    return { score, grade, crop, date };
}

export default function HistoryPage() {
    const navigate = useNavigate();
    const { farmerId, currentUser } = useAuth();
    const { t } = useLanguage();
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        // Always prefer the authenticated user's Cognito sub as farmer_id.
        // localStorage values may be stale from a previous session and will cause 403s.
        const id = currentUser?.sub
            || farmerId
            || localStorage.getItem('terraos_farmer_id')
            || localStorage.getItem('farmer_id');

        console.log('[HistoryPage] resolved farmerId:', id, '| currentUser.sub:', currentUser?.sub);

        if (!id) { setLoading(false); return; }

        fetchAllReports(id)
            .then(data => {
                console.log('[HistoryPage] API response:', data);
                setReports(data.reports || []);
            })
            .catch(e => {
                console.error('[HistoryPage] fetch error:', e);
                setError(e.message || 'Failed to load reports.');
            })
            .finally(() => setLoading(false));
    }, [farmerId, currentUser?.sub]);

    const handleReportClick = (report) => {
        // Navigate to /report with the full nested report object
        navigate('/report', { state: { report: report.full_report || report } });
    };

    return (
        <div className="page-with-topnav" style={{ background: 'var(--mist)', minHeight: '100vh', padding: '1.5rem', paddingBottom: 100 }}>
            {/* Desktop top nav */}
            <div style={{ display: 'none' }} className="desktop-nav"><TopNav /></div>

            {/* ── Header ── */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <button className="back-btn" onClick={() => navigate('/home')}>←</button>
                <div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.2rem', fontWeight: 700 }}>{t('history.title')}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('history.subtitle')}</div>
                </div>
                {reports.length > 0 && (
                    <div style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 4, padding: '4px 12px', background: 'var(--leaf)', color: 'white', borderRadius: 20, fontSize: '0.78rem', fontWeight: 700 }}>
                        📋 {reports.length} {reports.length !== 1 ? t('history.reports.count') : t('history.report.count')}
                    </div>
                )}
            </div>

            {/* ── Loading ── */}
            {loading && (
                <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '4rem' }}>
                    <div style={{ width: 40, height: 40, borderRadius: '50%', border: '3px solid var(--mist)', borderTopColor: 'var(--leaf)', animation: 'spin 0.8s linear infinite', margin: '0 auto 1rem' }} />
                    {t('history.loading')}
                    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
                </div>
            )}

            {/* ── Error ── */}
            {!loading && error && (
                <div style={{ maxWidth: 700, margin: '0 auto', background: '#fff3f3', border: '1px solid rgba(200,50,50,0.2)', borderRadius: 12, padding: '1.5rem', textAlign: 'center' }}>
                    <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>⚠️</div>
                    <div style={{ color: '#c62828', fontSize: '0.9rem' }}>{error}</div>
                    <button onClick={() => navigate('/analyze')} className="btn-primary" style={{ maxWidth: 200, marginTop: '1rem' }}>{t('history.btn.analyze')}</button>
                </div>
            )}

            {/* ── Empty state ── */}
            {!loading && !error && reports.length === 0 && (
                <div style={{ maxWidth: 700, margin: '0 auto', background: 'white', borderRadius: 20, padding: '3rem 2rem', boxShadow: 'var(--shadow)', textAlign: 'center' }}>
                    <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🌱</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.3rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>{t('history.empty.title')}</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', lineHeight: 1.6, marginBottom: '1.5rem' }}>
                        {t('history.empty.desc')}
                    </div>
                    <button onClick={() => navigate('/analyze')} className="btn-primary" style={{ maxWidth: 240, margin: '0 auto' }}>
                        {t('history.empty.btn')}
                    </button>
                </div>
            )}

            {/* ── Report list ── */}
            {!loading && !error && reports.map((r, i) => {
                const { score, grade, crop, date } = getReportDisplay(r);
                const color = getScoreColor(score);

                return (
                    <div
                        key={r.report_id || i}
                        className="report-list-item"
                        style={{ maxWidth: 700, margin: '0 auto 1rem', cursor: 'pointer' }}
                        onClick={() => handleReportClick(r)}
                    >
                        {/* Score ring */}
                        <div style={{ width: 52, height: 52, borderRadius: '50%', background: `conic-gradient(${color} ${score}%, #e8f5e9 0)`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '0.9rem', fontWeight: 700, color: 'var(--moss)', lineHeight: 1 }}>{score}</div>
                                <div style={{ fontSize: '0.6rem', fontWeight: 700, color: 'var(--text-muted)' }}>{grade}</div>
                            </div>
                        </div>

                        {/* Info */}
                        <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: 3 }}>
                                {date}
                            </div>
                            <div style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                {crop}
                            </div>
                            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                                {t('history.score')}: {score}/100 · {t('history.grade')}: {grade}
                            </div>
                        </div>

                        <div style={{ color: 'var(--text-muted)', fontSize: '1.2rem', flexShrink: 0 }}>›</div>
                    </div>
                );
            })}

            {/* ── Trend chart — only shown with 2+ reports ── */}
            {!loading && !error && reports.length >= 2 && (() => {
                const CHART_H = 100; // px — height of the bar area
                const BAR_W = 36;  // px — width of each bar
                const scores = [...reports].reverse().map(r => getReportDisplay(r));
                const maxScore = Math.max(...scores.map(s => s.score), 1);

                return (
                    <div style={{ maxWidth: 700, margin: '1rem auto', background: 'white', borderRadius: 16, padding: '1.5rem', boxShadow: 'var(--shadow)' }}>

                        {/* Header */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: '1.2rem' }}>
                            <span style={{ fontSize: '1rem' }}>📈</span>
                            <span style={{ fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--text-muted)' }}>
                                {t('history.trend.title')}
                            </span>
                        </div>

                        {/* Bar chart */}
                        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, height: CHART_H, marginBottom: '0.5rem', paddingBottom: 0 }}>
                            {scores.map(({ score, color: _c, date, crop }, i) => {
                                const barH = Math.max(8, (score / maxScore) * (CHART_H - 24));
                                const color = getScoreColor(score);
                                const month = date && date !== 'N/A' ? date.split(' ').slice(0, 2).join(' ') : `R${i + 1}`;
                                return (
                                    <div
                                        key={i}
                                        style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, cursor: 'pointer' }}
                                        onClick={() => handleReportClick([...reports].reverse()[i])}
                                    >
                                        {/* Score label above bar */}
                                        <div style={{ fontSize: '0.7rem', fontWeight: 700, color, fontFamily: "'DM Sans', sans-serif" }}>
                                            {score}
                                        </div>
                                        {/* Bar */}
                                        <div style={{
                                            width: BAR_W,
                                            height: barH,
                                            background: `linear-gradient(180deg, ${color}cc, ${color})`,
                                            borderRadius: '6px 6px 2px 2px',
                                            transition: 'height 0.4s ease',
                                            boxShadow: `0 2px 8px ${color}40`,
                                        }} />
                                    </div>
                                );
                            })}
                        </div>

                        {/* Baseline */}
                        <div style={{ height: 1, background: 'var(--border)', marginBottom: '0.6rem' }} />

                        {/* X-axis labels */}
                        <div style={{ display: 'flex', gap: 16, marginBottom: '1rem' }}>
                            {scores.map(({ date }, i) => {
                                const month = date && date !== 'N/A' ? date.split(' ').slice(0, 2).join(' ') : `R${i + 1}`;
                                return (
                                    <div key={i} style={{ width: BAR_W, textAlign: 'center', fontFamily: "'DM Mono', monospace", fontSize: '0.6rem', color: 'var(--text-muted)' }}>
                                        {month}
                                    </div>
                                );
                            })}
                        </div>

                        {/* Trend message */}
                        <div style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.6, padding: '8px 12px', background: 'var(--mist)', borderRadius: 8 }}>
                            {scores[scores.length - 1]?.score >= scores[0]?.score
                                ? t('history.trend.improving')
                                : t('history.trend.declining')}
                        </div>
                    </div>
                );
            })()}


            <BottomNav />
            <style>{`
        @media (min-width: 768px) { .desktop-nav { display: block !important; } }
      `}</style>
        </div>
    );
}
