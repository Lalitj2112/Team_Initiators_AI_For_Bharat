import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { fetchReport } from '../services/api.js';

const MESSAGES = [
    'Analyzing NPK levels with Nova Pro AI...',
    'Running ecosystem inference in parallel...',
    'Generating regenerative recommendations...',
    'Checking historical soil trends...',
    'Calculating carbon credit potential...',
    'Finalizing your Gold report...',
];

const STEPS = [
    { icon: '🧪', text: 'NPK Agent — Soil chemistry analysis' },
    { icon: '🌿', text: 'Ecosystem Agent — Micronutrient inference' },
    { icon: '⚡', text: 'Suggestion Agent — Generating recommendations' },
    { icon: '📊', text: 'Historical Agent — Trend analysis' },
    { icon: '🌍', text: 'Carbon Agent — Credit calculation' },
];

export default function LoadingPage() {
    const navigate = useNavigate();
    const location = useLocation();
    const { farmerId: ctxFarmerId, updateLastReport } = useAuth();
    const { t } = useLanguage();

    const MESSAGES = [
        t('loading.step1'),
        t('loading.step2'),
        t('loading.step3'),
        t('loading.step4'),
        t('loading.step5'),
        t('loading.subtitle'),
    ];

    const STEPS = [
        { icon: '🧪', text: t('loading.step1') },
        { icon: '🌿', text: t('loading.step2') },
        { icon: '⚡', text: t('loading.step3') },
        { icon: '📊', text: t('loading.step4') },
        { icon: '🌍', text: t('loading.step5') },
    ];

    const farmerId = location.state?.farmerId || ctxFarmerId;

    const [msgIdx, setMsgIdx] = useState(0);
    const [stepState, setStepState] = useState(STEPS.map((_, i) => i === 0 ? 'active' : 'pending'));
    const [elapsed, setElapsed] = useState(0);
    const [timedOut, setTimedOut] = useState(false);
    const [error, setError] = useState('');
    const pollTimer = useRef(null);
    const stopPoll = useRef(false);

    // Cycling messages
    useEffect(() => {
        const t = setInterval(() => setMsgIdx(i => (i + 1) % MESSAGES.length), 3000);
        return () => clearInterval(t);
    }, []);

    // Elapsed counter
    useEffect(() => {
        const t = setInterval(() => setElapsed(s => s + 1), 1000);
        return () => clearInterval(t);
    }, []);

    // Step progression
    useEffect(() => {
        // Spread the 5 steps evenly across the 2-minute window
        const intervals = [15000, 35000, 55000, 80000, 105000];
        const timers = intervals.map((ms, idx) =>
            setTimeout(() => {
                setStepState(prev => prev.map((s, i) => {
                    if (i < idx + 1) return 'done';
                    if (i === idx + 1) return 'active';
                    return s;
                }));
            }, ms)
        );
        return () => timers.forEach(clearTimeout);
    }, []);

    // Poll for report
    useEffect(() => {
        if (!farmerId) { setError('No farmer ID. Please go back and analyze again.'); return; }
        stopPoll.current = false;
        const startTime = Date.now();

        // submittedAt tells us the earliest time the NEW report can have been created.
        // Any report with a timestamp BEFORE this is the old report — ignore it.
        const submittedAt = location.state?.submittedAt || startTime;
        const executionId = location.state?.executionId || null;

        const isNewReport = (data) => {
            // If the backend returns an execution_id, match on it
            if (executionId && data.execution_id) {
                return data.execution_id === executionId;
            }
            // Otherwise compare timestamp: report must be from AFTER the form was submitted
            const rawTs = data.timestamp || data.generated_at || '';
            if (!rawTs) return true; // can't tell — accept it
            const fixedTs = String(rawTs).replace(/T(\d{2})-(\d{2})-(\d{2})/, 'T$1:$2:$3');
            const reportTime = new Date(fixedTs).getTime();
            // Allow 30 s buffer for clock skew / Lambda delay
            return reportTime >= submittedAt - 30_000;
        };

        const poll = async () => {
            if (stopPoll.current) return;

            // Check timeout using wall-clock time (avoids stale closure on `elapsed`)
            const secondsElapsed = Math.floor((Date.now() - startTime) / 1000);
            if (secondsElapsed >= 120) { setTimedOut(true); return; }

            try {
                const data = await fetchReport(farmerId);
                if (data && typeof data === 'object' && Object.keys(data).length > 0) {
                    if (isNewReport(data)) {
                        // ✅ This is the freshly generated report
                        stopPoll.current = true;
                        updateLastReport(data);
                        navigate('/report', { state: { report: data, farmerId } });
                        return;
                    }
                    // Old report returned — keep polling
                    console.log('[LoadingPage] Got stale report, still waiting for new one…');
                }
            } catch (e) {
                // 404 / 'pending' / 'not ready' → report not ready yet, keep polling
                const msg = (e.message || '').toLowerCase();
                if (!msg.includes('404') && !msg.includes('pending') && !msg.includes('not found') && !msg.includes('not ready')) {
                    setError(e.message || 'Error fetching report.');
                    return;
                }
            }

            // Wait 3s then poll again
            pollTimer.current = setTimeout(poll, 3000);
        };

        // Start first poll after 5s to give the backend time to begin processing
        pollTimer.current = setTimeout(poll, 5000);
        return () => { stopPoll.current = true; clearTimeout(pollTimer.current); };
    }, [farmerId]); // eslint-disable-line

    const [softTimeout, setSoftTimeout] = useState(false); // shown after 45s, still polling

    const progressBarStyle = {
        height: '100%',
        background: 'linear-gradient(90deg, var(--sprout), var(--lime))',
        borderRadius: 100,
        width: '5%',
        animation: 'progress-fill 110s ease-out forwards',
    };

    // Soft timeout: show message after 90s but keep polling
    useEffect(() => {
        const t = setTimeout(() => setSoftTimeout(true), 90000);
        return () => clearTimeout(t);
    }, []);

    if (timedOut || error) {
        return (
            <div style={{ minHeight: '100vh', background: 'linear-gradient(160deg, var(--carbon) 0%, var(--soil-brown) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
                <div style={{ textAlign: 'center', color: 'white', maxWidth: 440 }}>
                    <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>⏱️</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: 700, marginBottom: '0.6rem' }}>
                        {timedOut ? 'Analysis taking longer' : 'Something went wrong'}
                    </div>
                    <div style={{ color: 'rgba(255,255,255,0.65)', marginBottom: '2rem', lineHeight: 1.6 }}>
                        {timedOut ? 'The AI is still processing. Please wait a moment and try fetching the report.' : error}
                    </div>
                    <button
                        onClick={() => navigate('/analyze')}
                        style={{ padding: '12px 32px', background: 'rgba(139,195,74,0.15)', color: 'var(--lime)', border: '1px solid rgba(139,195,74,0.3)', borderRadius: 8, fontFamily: "'DM Sans', sans-serif", fontSize: '0.9rem', cursor: 'pointer', marginRight: 12 }}
                    >
                        ← Analyze Again
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div style={{ minHeight: '100vh', background: 'linear-gradient(160deg, var(--carbon) 0%, var(--soil-brown) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
            <div style={{ textAlign: 'center', maxWidth: 440, width: '100%' }}>

                {/* Pulsing Orb */}
                <div style={{
                    width: 140, height: 140,
                    borderRadius: '50%',
                    background: 'radial-gradient(circle at 35% 35%, rgba(139,195,74,0.3), rgba(62,123,39,0.1))',
                    border: '2px solid rgba(139,195,74,0.3)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 2.5rem',
                    position: 'relative',
                    animation: 'pulse-orb 2s ease-in-out infinite',
                }}>
                    <div style={{ position: 'absolute', inset: -12, borderRadius: '50%', border: '1px solid rgba(139,195,74,0.15)', animation: 'spin 8s linear infinite' }} />
                    <div style={{ position: 'absolute', inset: -24, borderRadius: '50%', border: '1px dashed rgba(139,195,74,0.08)', animation: 'spin 12s linear infinite reverse' }} />
                    <div style={{ fontSize: '3rem' }}>🌿</div>
                </div>

                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: 700, color: 'white', marginBottom: '0.6rem' }}>
                    Analyzing Your Soil
                </div>
                <div style={{ color: 'var(--lime)', fontSize: '0.9rem', fontWeight: 500, marginBottom: '2rem', minHeight: '1.4em', fontFamily: "'DM Mono', monospace" }}>
                    {MESSAGES[msgIdx]}
                </div>

                {/* Progress bar */}
                <div style={{ background: 'rgba(255,255,255,0.1)', borderRadius: 100, height: 6, overflow: 'hidden', marginBottom: '0.6rem' }}>
                    <div style={progressBarStyle} />
                </div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.78rem', fontFamily: "'DM Mono', monospace", marginBottom: '2.5rem' }}>
                    {elapsed}s elapsed · ~{Math.max(0, 120 - elapsed)}s remaining · Est. 2 min
                </div>

                {/* Steps */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, textAlign: 'left' }}>
                    {STEPS.map(({ icon, text }, i) => {
                        const s = stepState[i];
                        return (
                            <div key={i} className={`loading-step loading-step-${s}`}>
                                <div style={{ fontSize: '1rem', width: 20, textAlign: 'center' }}>
                                    {s === 'done' ? '✅' : s === 'active' ? '⚡' : '⏳'}
                                </div>
                                <div style={{ fontSize: '0.85rem', color: 'white', flex: 1 }}>{text}</div>
                                <div style={{
                                    marginLeft: 'auto', fontSize: '0.75rem', fontFamily: "'DM Mono', monospace",
                                    color: s === 'done' ? 'var(--lime)' : s === 'active' ? 'var(--amber)' : 'rgba(255,255,255,0.3)',
                                    animation: s === 'active' ? 'blink 1s ease-in-out infinite' : 'none',
                                }}>
                                    {s === 'done' ? 'Done' : s === 'active' ? 'Running...' : 'Waiting'}
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* Soft-timeout: still polling but let user navigate to reports */}
                {softTimeout && (
                    <div style={{ marginTop: '1.5rem', background: 'rgba(212,160,23,0.15)', border: '1px solid rgba(212,160,23,0.3)', borderRadius: 12, padding: '1rem 1.2rem', textAlign: 'left' }}>
                        <div style={{ color: 'var(--gold)', fontWeight: 700, fontSize: '0.88rem', marginBottom: '0.4rem' }}>⏳ Report saved — loading…</div>
                        <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.8rem', lineHeight: 1.5, marginBottom: '0.8rem' }}>
                            Your report is saved. The API is still fetching it. You can also view it from the Reports tab.
                        </div>
                        <button
                            onClick={() => navigate('/history')}
                            style={{ padding: '8px 18px', background: 'rgba(212,160,23,0.2)', color: 'var(--gold)', border: '1px solid rgba(212,160,23,0.4)', borderRadius: 8, fontFamily: "'DM Sans', sans-serif", fontSize: '0.82rem', fontWeight: 600, cursor: 'pointer' }}
                        >
                            📋 Go to My Reports
                        </button>
                    </div>
                )}


                <style>{`
          @keyframes pulse-orb {
            0%,100% { box-shadow: 0 0 0 0 rgba(139,195,74,0.2), 0 0 40px rgba(62,123,39,0.2); }
            50%      { box-shadow: 0 0 0 20px rgba(139,195,74,0), 0 0 60px rgba(62,123,39,0.4); }
          }
          @keyframes spin { to { transform: rotate(360deg); } }
          @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.4} }
          @keyframes progress-fill { from { width: 5%; } to { width: 92%; } }
        `}</style>
            </div>
        </div>
    );
}
