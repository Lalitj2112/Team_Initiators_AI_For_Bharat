import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { fetchAllReports } from '../services/api.js';
import BottomNav from '../components/BottomNav.jsx';
import TopNav from '../components/TopNav.jsx';

export default function HomePage() {
    const navigate = useNavigate();
    const { currentUser, farmerId, lastReport, updateLastReport } = useAuth();
    const { t } = useLanguage();
    const name = currentUser?.name || 'Farmer';
    const email = currentUser?.email || '';

    const getGreeting = () => {
        const h = new Date().getHours();
        if (h < 12) return t('home.greeting.morning');
        if (h < 17) return t('home.greeting.afternoon');
        return t('home.greeting.evening');
    };

    const [latestReport, setLatestReport] = useState(lastReport);
    const [loadingLatest, setLoadingLatest] = useState(false);

    // Fetch the most recent report from history API on load
    useEffect(() => {
        // Always use the authenticated Cognito sub first — stale localStorage IDs cause 403s
        const resolvedId = currentUser?.sub
            || farmerId
            || localStorage.getItem('terraos_farmer_id')
            || localStorage.getItem('farmer_id');

        if (!resolvedId) return;

        setLoadingLatest(true);
        fetchAllReports(resolvedId)
            .then(data => {
                const reports = data.reports || [];
                if (reports.length > 0) {
                    const newest = reports[0]; // API returns newest first
                    setLatestReport(newest);
                    // Also persist to context so other pages benefit
                    if (!lastReport) updateLastReport(newest.full_report || newest);
                }
            })
            .catch(() => { }) // fail silently — homepage still works
            .finally(() => setLoadingLatest(false));
    }, [farmerId, currentUser?.sub]); // eslint-disable-line

    // Extract score, grade, crop, location from the report summary row
    const getDisplayData = (r) => {
        if (!r) return null;
        const fr = r.full_report || r;
        const fd = fr.farmer_data || {};
        const sum = fr.summary || {};

        const score = r.soil_score ?? sum.soil_score ?? fr.soil_score ?? 0;
        const grade = r.grade ?? sum.grade ?? fr.grade ?? '—';
        const crop = (r.crop_type && r.crop_type !== 'Unknown' ? r.crop_type : null)
            || fd.crop_type || fd.crop_planned || r.crop_planned || '';
        const location = r.location || fd.location || '';
        const ts = r.timestamp || fr.timestamp || fr.generated_at || '';
        const fixedTs = String(ts).replace(/T(\d{2})-(\d{2})-(\d{2})/, 'T$1:$2:$3');
        const dateStr = ts ? new Date(fixedTs).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Recent';

        return { score, grade, crop, location, dateStr };
    };

    const display = getDisplayData(latestReport);

    return (
        <div style={{ background: 'var(--mist)', minHeight: '100vh', paddingBottom: 80 }}>
            {/* Desktop top nav */}
            <div style={{ display: 'none' }} className="desktop-nav"><TopNav /></div>

            {/* ─── Hero ─── */}
            <div style={{
                background: 'linear-gradient(135deg, var(--carbon) 0%, var(--moss) 60%, var(--leaf) 100%)',
                padding: '4rem 2rem 5rem',
                position: 'relative',
                overflow: 'hidden',
            }}>
                <div style={{
                    position: 'absolute', inset: 0,
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                    pointerEvents: 'none',
                }} />

                <div style={{ maxWidth: 700, margin: '0 auto', position: 'relative', zIndex: 1 }}>
                    <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9rem', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '0.4rem' }}>
                        {getGreeting()}
                    </div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(1.5rem, 4vw, 2rem)', fontWeight: 700, color: 'white', marginBottom: '0.3rem' }}>
                        Namaste, {name} 🙏
                    </div>
                    <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem', marginBottom: '2rem', fontFamily: "'DM Mono', monospace" }}>
                        {email}
                    </div>

                    <button
                        onClick={() => navigate('/analyze')}
                        style={{
                            display: 'inline-flex', alignItems: 'center', gap: 10,
                            padding: '14px 28px',
                            background: 'var(--lime)', color: 'var(--soil-dark)',
                            border: 'none', borderRadius: 50,
                            fontFamily: "'DM Sans', sans-serif",
                            fontSize: '0.95rem', fontWeight: 700,
                            cursor: 'pointer',
                            transition: 'transform 0.2s, box-shadow 0.2s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(139,195,74,0.4)'; }}
                        onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
                    >
                        {t('home.cta')}
                    </button>
                </div>
            </div>

            {/* ─── Cards ─── */}
            <div style={{ maxWidth: 760, margin: '-2.5rem auto 0', padding: '0 1.5rem 2rem', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.2rem' }}>

                {/* Analyze card */}
                <div className="home-card" onClick={() => navigate('/analyze')}>
                    <div style={{ width: 44, height: 44, borderRadius: 12, background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', marginBottom: '1rem' }}>🧪</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--text-muted)', marginBottom: 4 }}>{t('home.card.new.tag')}</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.15rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>{t('home.card.new.title')}</div>
                    <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>{t('home.card.new.desc')}</div>
                </div>

                {/* History card */}
                <div className="home-card" onClick={() => navigate('/history')}>
                    {latestReport && (
                        <div style={{ position: 'absolute', top: '1rem', right: '1rem', background: 'var(--leaf)', color: 'white', fontSize: '0.7rem', fontWeight: 700, padding: '3px 10px', borderRadius: 20 }}>
                            View All
                        </div>
                    )}
                    <div style={{ width: 44, height: 44, borderRadius: 12, background: '#fbe9e7', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', marginBottom: '1rem' }}>📋</div>
                    <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--text-muted)', marginBottom: 4 }}>{t('home.card.history.tag')}</div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.15rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>{t('home.card.history.title')}</div>
                    <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.5 }}>{t('home.card.history.desc')}</div>
                </div>

                {/* Latest score — full width */}
                <div className="home-card" style={{ gridColumn: '1 / -1' }}>
                    {loadingLatest ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'var(--text-muted)', fontSize: '0.88rem' }}>
                            <div style={{ width: 20, height: 20, borderRadius: '50%', border: '2px solid var(--mist)', borderTopColor: 'var(--leaf)', animation: 'spin 0.8s linear infinite' }} />
                            {t('home.loading')}
                            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
                        </div>
                    ) : display ? (
                        <>
                            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--text-muted)', marginBottom: 4 }}>{t('home.score.tag')}</div>
                            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.15rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.8rem' }}>{t('home.score.title')}</div>
                            <div
                                style={{ display: 'flex', alignItems: 'center', gap: '1.2rem', cursor: 'pointer' }}
                                onClick={() => navigate('/report', { state: { report: latestReport.full_report || latestReport } })}
                            >
                                {/* Score ring */}
                                <div style={{
                                    width: 64, height: 64, borderRadius: '50%', flexShrink: 0,
                                    background: `conic-gradient(${display.score >= 80 ? '#5A9E3A' : display.score >= 60 ? '#3E7B27' : '#F59E0B'} ${display.score}%, #e8f5e9 0)`,
                                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                                }}>
                                    <div style={{ width: 50, height: 50, borderRadius: '50%', background: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                                        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1rem', fontWeight: 700, color: 'var(--moss)' }}>{display.score}</div>
                                        <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>/100</div>
                                    </div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--text-primary)' }}>
                                        {display.crop && <span>{display.crop}{display.location ? ' · ' : ''}</span>}
                                        {display.location && <span>{display.location}</span>}
                                        {!display.crop && !display.location && 'Soil Analysis'}
                                    </div>
                                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 2 }}>
                                        {display.dateStr} · Grade {display.grade}
                                    </div>
                                    <div style={{ fontSize: '0.78rem', color: 'var(--leaf)', marginTop: 4, fontWeight: 500 }}>{t('home.score.link')}</div>
                                </div>
                            </div>
                        </>
                    ) : (
                        <>
                            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--text-muted)', marginBottom: 4 }}>{t('home.empty.tag')}</div>
                            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.15rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.8rem' }}>{t('home.empty.title')}</div>
                            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: 1.5, marginBottom: '1rem' }}>
                                {t('home.empty.desc')}
                            </div>
                            <button onClick={() => navigate('/analyze')} className="btn-primary" style={{ maxWidth: 220 }}>
                                {t('home.empty.btn')}
                            </button>
                        </>
                    )}
                </div>
            </div>

            <BottomNav />

            <style>{`
        @media (min-width: 768px) { .desktop-nav { display: block !important; } }
        @media (max-width: 767px) {
          div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
        </div>
    );
}
