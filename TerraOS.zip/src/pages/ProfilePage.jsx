import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useLanguage } from '../context/LanguageContext.jsx';
import { fetchAllReports } from '../services/api.js';
import BottomNav from '../components/BottomNav.jsx';
import TopNav from '../components/TopNav.jsx';

export default function ProfilePage() {
    const navigate = useNavigate();
    const { currentUser, farmerId, lastReport, signOut } = useAuth();
    const { t } = useLanguage();
    const [signingOut, setSigningOut] = useState(false);
    const [reportStats, setReportStats] = useState({ count: 0, firstDate: null, latestScore: null, latestGrade: null });
    const [statsLoading, setStatsLoading] = useState(true);

    // Resolve farmer ID from all possible sources (same logic as HistoryPage)
    const resolvedId = farmerId
        || localStorage.getItem('terraos_farmer_id')
        || localStorage.getItem('farmer_id')
        || currentUser?.sub;

    const name = currentUser?.name || 'Farmer';
    const email = currentUser?.email || '—';
    const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

    // Fetch real stats from history API
    useEffect(() => {
        if (!resolvedId) { setStatsLoading(false); return; }

        fetchAllReports(resolvedId)
            .then(data => {
                const reports = data.reports || [];
                if (reports.length === 0) { setStatsLoading(false); return; }

                // Sorted newest first from the API, so last item is oldest
                const latest = reports[0];
                const oldest = reports[reports.length - 1];

                // Parse timestamp (handle non-standard T20-48-24Z format)
                const parseTs = (ts) => {
                    if (!ts) return null;
                    return new Date(String(ts).replace(/T(\d{2})-(\d{2})-(\d{2})/, 'T$1:$2:$3'));
                };

                const firstDate = parseTs(oldest?.timestamp);
                const firstDateStr = firstDate && !isNaN(firstDate)
                    ? firstDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
                    : null;

                setReportStats({
                    count: reports.length,
                    firstDate: firstDateStr,
                    latestScore: latest?.soil_score ?? null,
                    latestGrade: latest?.grade ?? null,
                });
            })
            .catch(() => { }) // fail silently — show '—' for stats
            .finally(() => setStatsLoading(false));
    }, [resolvedId]); // eslint-disable-line

    const handleSignOut = async () => {
        setSigningOut(true);
        try { await signOut(); navigate('/'); }
        catch { setSigningOut(false); }
    };

    const statVal = (v) => statsLoading ? '…' : (v ?? '—');

    const statCard = (label, value, icon) => (
        <div style={{ background: 'white', borderRadius: 12, padding: '1rem', boxShadow: 'var(--shadow)', textAlign: 'center' }}>
            <div style={{ fontSize: '1.4rem', marginBottom: 4 }}>{icon}</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.2rem', fontWeight: 700, color: 'var(--moss)' }}>{value}</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
        </div>
    );

    return (
        <div className="page-with-topnav" style={{ background: 'var(--mist)', minHeight: '100vh', padding: '1.5rem', paddingBottom: 100 }}>
            {/* Desktop top nav */}
            <div style={{ display: 'none' }} className="desktop-nav"><TopNav /></div>

            {/* Header */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <button className="back-btn" onClick={() => navigate('/home')}>←</button>
                <div>
                    <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.2rem', fontWeight: 700 }}>{t('profile.title')}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('profile.subtitle')}</div>
                </div>
            </div>

            {/* Profile hero card */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', background: 'linear-gradient(135deg, var(--carbon) 0%, var(--moss) 100%)', borderRadius: 20, padding: '2rem', position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', top: -40, right: -40, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, rgba(139,195,74,0.15), transparent 70%)' }} />
                <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', position: 'relative', zIndex: 1 }}>
                    {/* Avatar */}
                    <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, var(--leaf), var(--sprout))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontFamily: "'Playfair Display', serif", fontSize: '1.6rem', fontWeight: 700, flexShrink: 0 }}>
                        {initials}
                    </div>
                    <div>
                        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.4rem', fontWeight: 700, color: 'white', marginBottom: 4 }}>{name}</div>
                        <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.85rem', color: 'rgba(255,255,255,0.65)' }}>{email}</div>
                        {resolvedId && (
                            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: '0.72rem', color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>
                                ID: {resolvedId.slice(0, 14)}…
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Dynamic stats */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                {statCard(t('profile.stat.analyses'), statVal(reportStats.count || (resolvedId ? undefined : '—')), '🧪')}
                {statCard(t('profile.stat.first'), statVal(reportStats.firstDate), '📅')}
                {statCard(t('profile.stat.score'),
                    reportStats.latestScore !== null
                        ? statVal(`${reportStats.latestScore}/100`)
                        : statVal(null),
                    '🏆'
                )}
            </div>

            {/* Latest score grade badge */}
            {!statsLoading && reportStats.latestGrade && (
                <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', background: 'white', borderRadius: 12, padding: '12px 1.5rem', boxShadow: 'var(--shadow)', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--mist)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.1rem', color: 'var(--moss)' }}>
                        {reportStats.latestGrade}
                    </div>
                    <div>
                        <div style={{ fontWeight: 600, fontSize: '0.88rem', color: 'var(--text-primary)' }}>{t('profile.grade')}</div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{t('profile.grade.sub')} · {reportStats.count} {reportStats.count !== 1 ? t('profile.reports') : t('profile.report')} {t('profile.total')}</div>
                    </div>
                    <button onClick={() => navigate('/history')} style={{ marginLeft: 'auto', padding: '6px 14px', background: 'var(--mist)', border: 'none', borderRadius: 8, fontSize: '0.78rem', fontWeight: 600, cursor: 'pointer', color: 'var(--moss)' }}>
                        {t('profile.grade.viewall')}
                    </button>
                </div>
            )}

            {/* Account details */}
            <div style={{ maxWidth: 700, margin: '0 auto 1.5rem', background: 'white', borderRadius: 16, padding: '1.5rem', boxShadow: 'var(--shadow)' }}>
                <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '1rem', fontWeight: 700, marginBottom: '1.2rem' }}>{t('profile.section.account')}</div>
                {[
                    { label: t('profile.field.name'), value: name },
                    { label: t('profile.field.email'), value: email },
                    { label: t('profile.field.id'), value: resolvedId || 'Not assigned yet', mono: true },
                    { label: t('profile.field.region'), value: `India · ${import.meta.env.VITE_AWS_REGION || 'ap-south-1'}` },
                ].map(({ label, value, mono }) => (
                    <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                        <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', flexShrink: 0 }}>{label}</span>
                        <span style={{ fontSize: '0.82rem', color: 'var(--text-primary)', fontFamily: mono ? "'DM Mono', monospace" : "'DM Sans', sans-serif", fontWeight: 500, maxWidth: '60%', textAlign: 'right', wordBreak: 'break-all' }}>
                            {value}
                        </span>
                    </div>
                ))}
            </div>

            {/* Actions */}
            <div style={{ maxWidth: 700, margin: '0 auto' }}>
                <button
                    onClick={() => navigate('/analyze')}
                    style={{ width: '100%', padding: 14, marginBottom: '0.8rem', background: 'linear-gradient(135deg, var(--moss), var(--leaf))', color: 'white', border: 'none', borderRadius: 12, fontFamily: "'DM Sans', sans-serif", fontSize: '0.95rem', fontWeight: 600, cursor: 'pointer' }}
                >
                    {t('profile.btn.analyze')}
                </button>
                <button
                    onClick={() => navigate('/history')}
                    style={{ width: '100%', padding: 14, marginBottom: '0.8rem', background: 'white', color: 'var(--moss)', border: '1.5px solid var(--border)', borderRadius: 12, fontFamily: "'DM Sans', sans-serif", fontSize: '0.95rem', fontWeight: 600, cursor: 'pointer' }}
                >
                    {t('profile.btn.reports')} ({statsLoading ? '…' : reportStats.count})
                </button>
                <button
                    onClick={handleSignOut}
                    disabled={signingOut}
                    style={{ width: '100%', padding: 14, background: 'white', color: '#c62828', border: '1.5px solid #fce4ec', borderRadius: 12, fontFamily: "'DM Sans', sans-serif", fontSize: '0.95rem', fontWeight: 600, cursor: 'pointer', opacity: signingOut ? 0.7 : 1 }}
                >
                    {signingOut ? t('profile.btn.signingout') : t('profile.btn.signout')}
                </button>
            </div>

            <BottomNav />

            <style>{`
        @media (min-width: 768px) { .desktop-nav { display: block !important; } }
        @media (max-width: 480px) {
          div[style*="grid-template-columns: 1fr 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
        </div>
    );
}
