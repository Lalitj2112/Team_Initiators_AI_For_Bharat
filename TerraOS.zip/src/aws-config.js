import { Amplify } from 'aws-amplify';

Amplify.configure({
    Auth: {
        Cognito: {
            userPoolId: import.meta.env.VITE_USER_POOL_ID,        // e.g. ap-south-1_k5mqRYxZ4
            userPoolClientId: import.meta.env.VITE_USER_POOL_CLIENT_ID, // e.g. 3abc123xyz... (App Client ID, NOT Identity Pool ID)
            region: import.meta.env.VITE_AWS_REGION || 'ap-south-1',
            loginWith: { email: true },
            userAttributes: {
                email: { required: true },
                name: { required: true },
            },
        },
    },
    API: {
        REST: {
            TerraOSAPI: {
                endpoint: import.meta.env.VITE_API_GATEWAY_URL,           // e.g. https://qnd8fmuj75.execute-api.ap-south-1.amazonaws.com/prod
                region: import.meta.env.VITE_AWS_REGION || 'ap-south-1',
            },
        },
    },
});
